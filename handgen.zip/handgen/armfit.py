"""`arm` mode: forearm numbers for the Fusion model from a scan that includes forearm (SPEC S3).

The scan must end in a flat cap across the forearm. X is the inward normal of that cap. The wrist section is the section of
smallest tape girth between the cap and the hand; widths and thicknesses are the extents of the sections in Y and Z."""
import numpy as np
from scipy.spatial import ConvexHull


def section(mesh, x):
    sec = mesh.section(plane_origin=[x, 0, 0], plane_normal=[1, 0, 0])
    if sec is None:
        return None
    P = np.concatenate([e for e in sec.discrete])[:, 1:]
    return dict(x=float(x), width=float(np.ptp(P[:, 0])), thickness=float(np.ptp(P[:, 1])), girth=float(ConvexHull(P).area), centre=[float(P[:, 0].mean()), float(P[:, 1].mean())])


def find_wrist(mesh_cap_frame, search=(20.0, 260.0), step=2.0):
    """In the frame of the forearm cap (x = 0 at the cap, hand toward +x): x of the smallest girth."""
    xs = np.arange(search[0], min(search[1], mesh_cap_frame.vertices[:, 0].max() - 40.0), step)
    secs = [s for s in (section(mesh_cap_frame, x) for x in xs) if s]
    g = np.array([s['girth'] for s in secs])
    k = int(np.argmin(g))
    return secs[k]['x'], secs


def arm_parameters(mesh_device, fore_dist=140.0, presets=None):
    """mesh_device: scan in the device frame (wrist section at x = 0, forearm toward -x)."""
    xmin = float(mesh_device.vertices[:, 0].min())
    d = min(fore_dist, -xmin - 5.0)
    w, f = section(mesh_device, 0.0), section(mesh_device, -d)
    out = dict(wrist_w=round(w['width'], 1), wrist_t=round(w['thickness'], 1), fore_w=round(f['width'], 1), fore_t=round(f['thickness'], 1),
               fore_dist=round(d, 1), cuff_len=round(min(130.0, d - 10.0), 1), forearm_in_scan_mm=round(-xmin, 1),
               wrist_girth=round(w['girth'], 1), forearm_girth=round(f['girth'], 1))
    if presets:
        best = min(presets.items(), key=lambda kv: abs(kv[1]['girth'] - f['girth'] * (140.0 / d if d < 140 else 1.0)))
        out['nearest_preset'] = best[0]
    out['fusion'] = {k: f'{out[k]} mm' for k in ('wrist_w', 'wrist_t', 'fore_w', 'fore_t', 'fore_dist', 'cuff_len')}
    return out
