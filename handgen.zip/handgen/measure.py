"""Measurements taken from a hand scan in the device frame."""
import numpy as np
from scipy import ndimage
from scipy.spatial import ConvexHull, Delaunay


def wrist_and_hand(mesh):
    V = mesh.vertices
    sec = mesh.section(plane_origin=[1.0, 0, 0], plane_normal=[1, 0, 0])
    P = np.concatenate([e for e in sec.discrete])[:, 1:]
    hull = ConvexHull(P)
    return dict(wrist_width_mm=round(float(np.ptp(P[:, 0])), 1), wrist_thickness_mm=round(float(np.ptp(P[:, 1])), 1),
                wrist_girth_tape_mm=round(float(hull.area), 1),          # for 2D hulls scipy's `area` is the perimeter
                hand_length_beyond_wrist_mm=round(float(V[:, 0].max()), 1), hand_width_mm=round(float(np.ptp(V[:, 1])), 1),
                lowest_skin_z_mm=round(float(V[:, 2].min()), 2), extents_y=[round(float(V[:, 1].min()), 1), round(float(V[:, 1].max()), 1)],
                farthest_point_from_wrist_mm=round(float(np.linalg.norm(V, axis=1).max()), 1))


def curl_cylinder(mesh, pitch=1.0, seg=70.0, core=50.0, thetas=range(40, 92, 2), n_cand=3000):
    """Largest straight cylinder that fits the relaxed curl: over axis directions in the palm plane (theta from +X toward the
    thumb, -Y) and centre points in the hollow, maximise the smallest skin clearance along a `seg` mm segment whose central
    `core` mm lies inside the hand's convex hull. Returns radius, centre, direction."""
    import trimesh
    vg = mesh.voxelized(pitch).fill()
    occ, T = vg.matrix, vg.transform
    Tinv = np.linalg.inv(T)
    idx = np.argwhere(np.ones_like(occ))
    pts = trimesh.transform_points(idx.astype(float), T)
    inhull = (Delaunay(mesh.convex_hull.vertices).find_simplex(pts) >= 0).reshape(occ.shape)
    dist = ndimage.distance_transform_edt(~occ) * pitch
    cand = np.argwhere(inhull & ~occ & (dist >= 6.0))
    rng = np.random.default_rng(0)
    cand = cand[rng.choice(len(cand), size=min(n_cand, len(cand)), replace=False)]
    C = trimesh.transform_points(cand.astype(float), T)
    s = np.linspace(-seg / 2, seg / 2, int(seg) + 1)
    in_core = np.abs(s) <= core / 2

    def sample(field, Pq, order=1):
        q = trimesh.transform_points(Pq.reshape(-1, 3), Tinv).T
        return ndimage.map_coordinates(field.astype(float), q, order=order, mode='constant', cval=0.0).reshape(Pq.shape[:-1])
    best = dict(radius=0.0)
    for th in thetas:
        u = np.array([np.cos(np.radians(th)), -np.sin(np.radians(th)), 0.0])
        Pq = C[:, None, :] + s[None, :, None] * u[None, None, :]
        d = sample(dist, Pq)
        ok = (sample(inhull, Pq, 0) > 0.5)[:, in_core].all(1) & ~(sample(occ, Pq, 0) > 0.5).any(1)
        r = np.where(ok, d.min(1), 0.0)
        i = int(np.argmax(r))
        if r[i] > best['radius']:
            best = dict(radius=float(r[i]), centre=C[i].tolist(), theta_deg=float(th), direction=u.tolist())
    best['diameter'] = 2 * best['radius']
    best['method'] = f'voxel distance field at {pitch} mm, {len(C)} centre candidates, theta {thetas.start} to {thetas.stop - thetas.step} deg'
    return best
