"""Pad (TPU), tray (PETG) and strap pad (TPU) from a hand scan in the device frame, and the scoring of a pad against a scan."""
import os, json
import numpy as np
import trimesh
import manifold3d as m3
from scipy import ndimage
from scipy.spatial import cKDTree
from .hfield import prism, largest_component

HERE = os.path.dirname(os.path.abspath(__file__))
IFACE = json.load(open(os.path.join(HERE, 'interface', 'interface.json')))
M = m3.Manifold

DEFAULTS = dict(
    pitch=0.5,            # grid spacing of the height field, mm
    gap=0.2,              # clearance left between pad and scanned skin, mm (one printed layer)
    pad_min_t=3.0,        # least pad thickness under the lowest skin, mm
    base_t=0.8,           # soft floor over the whole tray, mm
    zone_z=-5.0,          # contact zone: skin below this height (SPEC A5)
    zone_cap=0.5,         # the pad rises to zone_z + zone_cap at most (except the grip bar)
    zone_margin=4.0,      # the raised pad reaches this far around the contact zone, mm
    pad_slope_deg=55.0,   # steepest slope of the pad surface: on steeper skin the pad falls away instead of forming a wall beside it
    pad_margin=2.5,       # pad outline = hand outline grown by this, mm
    tray_margin=3.0,      # inner face of the tray rim = hand outline grown by this, mm
    rim_t=2.4, rim_h=8.0, ear_h=16.0, ear_x=62.0, ear_half_len=16.0,
    hole_d=10.0, hole_pitch=13.5,
    bar_clear=0.4, bar_max_d=18.4,     # grip bar: curl radius minus bar_clear, never more than 18.4 mm across (SPEC A4)
    bar_half_len=31.0,                 # the bar reaches this far each side of the curl centre at most
    strap_pad=(32.0, 1.2),
    outline_sigma=0.6,    # second styling pass: the outlines are the half level of the grid mask blurred by this much, mm (no stair-steps)
    outline_step=0.25,    # spacing of the outline points, mm
    outline_max_turn=12.0,  # no outline vertex turns by more than this, degrees (SPEC section 11: 15 at most)
    rim_round=1.0,        # radius on both top edges of the tray rim and ears, mm
    ear_corner=2.0,       # radius at the top corners and at the foot of the ears, seen from the side, mm
    rear_corner=3.0,      # radius of the tray's two rear corners in plan, mm (2 mm on the pad)
    pad_clear=0.5,        # gap between the pad's edge and the inner face of the rim, mm
)


def to_manifold(v, f):
    return M(m3.Mesh(vert_properties=np.asarray(v, np.float32), tri_verts=np.asarray(f, np.uint32)))


def heal(V, F):
    """Before triangles of no height are dropped: where the three corners of one lie on a line (this comes out of the union of the
    tray's slices), the triangle on the other side of its long edge is split at the middle corner, so that dropping it leaves the
    mesh closed. Returns the faces; unchanged if there is no such triangle."""
    F = np.asarray(F).copy()
    for _ in range(2000):
        e = np.stack([np.linalg.norm(V[F[:, (k + 1) % 3]] - V[F[:, k]], axis=1) for k in range(3)], 1)
        area2 = np.linalg.norm(np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]]), axis=1)
        distinct = (F[:, 0] != F[:, 1]) & (F[:, 1] != F[:, 2]) & (F[:, 0] != F[:, 2])
        bad = np.nonzero(distinct & (area2 / np.maximum(e.max(1), 1e-12) < 1e-6))[0]      # ten times the height below which a triangle is dropped afterwards
        if len(bad) == 0:
            break
        b = bad[0]
        t, k = F[b], int(np.argmax(e[b]))
        p, q, mid = t[k], t[(k + 1) % 3], t[(k + 2) % 3]          # long edge p -> q; the third corner lies on it
        other = [o for o in np.nonzero((F == p).any(1) & (F == q).any(1))[0] if o != b]
        keep = np.ones(len(F), bool); keep[b] = False
        add = []
        if len(other) == 1:
            g = F[other[0]]
            x = [v for v in g if v != p and v != q][0]
            fwd = g[(list(g).index(p) + 1) % 3] == q                # winding of the neighbour: p -> q or q -> p
            add = [[p, mid, x], [mid, q, x]] if fwd else [[q, mid, x], [mid, p, x]]
            keep[other[0]] = False
        F = np.concatenate([F[keep], np.asarray(add, F.dtype).reshape(-1, 3)])
    return F


def to_trimesh(m):
    me = m.to_mesh()
    t = trimesh.Trimesh(np.asarray(me.vert_properties)[:, :3].astype(float), np.asarray(me.tri_verts), process=False)
    t.merge_vertices(digits_vertex=4)
    F = heal(np.asarray(t.vertices), np.asarray(t.faces))
    if len(F) != len(t.faces) or not np.array_equal(F, t.faces):
        t = trimesh.Trimesh(np.asarray(t.vertices), F, process=False)
    t.update_faces(t.nondegenerate_faces(height=1e-7))
    t.remove_unreferenced_vertices()
    if not t.is_watertight:                              # welding points 1e-4 mm apart opened the mesh (smooth-outline tray): keep the solid as built, which is closed
        V = np.asarray(me.vert_properties)[:, :3].astype(np.float32).astype(float)       # as an STL file will hold them
        t = trimesh.Trimesh(V, heal(V, np.asarray(me.tri_verts)), process=False)
    return t


def box(x, y, z):
    return M.cube([x[1] - x[0], y[1] - y[0], z[1] - z[0]]).translate([x[0], y[0], z[0]])


class Grid:
    """Regular grid of nodes at (x0 + i p, y0 + j p)."""
    def __init__(self, lo, hi, pitch, margin=10.0):
        self.p = pitch
        self.x0, self.y0 = np.floor(lo[0]) - margin, np.floor(lo[1]) - margin
        self.nx = int(np.ceil((hi[0] + margin - self.x0) / pitch)) + 1
        self.ny = int(np.ceil((hi[1] + margin - self.y0) / pitch)) + 1
        self.X, self.Y = np.meshgrid(self.x0 + pitch * np.arange(self.nx), self.y0 + pitch * np.arange(self.ny), indexing='ij')

    def index(self, P):
        i = np.clip(np.rint((P[:, 0] - self.x0) / self.p).astype(int), 0, self.nx - 1)
        j = np.clip(np.rint((P[:, 1] - self.y0) / self.p).astype(int), 0, self.ny - 1)
        return i, j

    def it(self, mm):
        return max(1, int(round(mm / self.p)))

    def cells(self, nodes):
        return nodes[:-1, :-1] & nodes[1:, :-1] & nodes[:-1, 1:] & nodes[1:, 1:]


def lower_envelope(mesh, grid):
    """Lowest skin height over each node (vertices and face centres binned to the nearest node), +inf outside the hand's outline."""
    P = np.concatenate([mesh.vertices, mesh.triangles_center])
    i, j = grid.index(P)
    env = np.full((grid.nx, grid.ny), np.inf)
    np.minimum.at(env, (i, j), P[:, 2])
    have = np.isfinite(env)
    foot = ndimage.binary_fill_holes(ndimage.binary_closing(have, iterations=2))
    for _ in range(6):                                   # nodes that no sample fell on take the lowest neighbour
        miss = foot & ~np.isfinite(env)
        if not miss.any():
            break
        env[miss] = ndimage.minimum_filter(env, size=3)[miss]
    env[~foot] = np.inf
    return env, foot


def upper_envelope(mesh, grid):
    P = np.concatenate([mesh.vertices, mesh.triangles_center])
    i, j = grid.index(P)
    top = np.full((grid.nx, grid.ny), -np.inf)
    np.maximum.at(top, (i, j), P[:, 2])
    return top


def bar_from_curl(curl, foot, grid, o):
    """Grip bar: a cylinder on the curl axis, radius = curl radius - bar_clear (at most bar_max_d / 2), as long as the axis stays under the hand."""
    c, u = np.array(curl['centre']), np.array(curl['direction'])
    r = min(curl['radius'] - o['bar_clear'], o['bar_max_d'] / 2)
    s = np.arange(-80.0, 80.01, 0.5)
    pts = c[None, :2] + s[:, None] * u[None, :2]
    i, j = grid.index(pts)
    ok = foot[i, j]
    k0 = int(np.argmin(np.abs(s)))
    a = k0
    while a > 0 and ok[a - 1]:
        a -= 1
    b = k0
    while b < len(s) - 1 and ok[b + 1]:
        b += 1
    s0, s1 = max(float(s[a] + 2.0), -o['bar_half_len']), min(float(s[b] - 2.0), o['bar_half_len'])
    return dict(centre=c.tolist(), direction=u.tolist(), r=float(r), diameter=float(2 * r), s0=s0, s1=s1, length=s1 - s0)


def slope_limited(f, grid, slope_deg, radius_mm=26.0):
    """Highest surface that lies below f everywhere and is nowhere steeper than slope_deg:
    g(p) = min over q of [f(q) + tan(slope) * |p - q|] (a grey erosion with a cone)."""
    r = grid.it(radius_mm)
    a = np.arange(-r, r + 1) * grid.p
    D = np.hypot(*np.meshgrid(a, a, indexing='ij'))
    return ndimage.grey_erosion(np.where(np.isfinite(f), f, 1e3), structure=-(np.tan(np.radians(slope_deg)) * D))


def _turns(P):
    """Turning angle at every vertex of a closed polyline, degrees."""
    a, b = P - np.roll(P, 1, 0), np.roll(P, -1, 0) - P
    return np.degrees(np.abs(np.arctan2(a[:, 0] * b[:, 1] - a[:, 1] * b[:, 0], (a * b).sum(1))))


def _resample(P, step):
    d = np.hypot(*np.diff(np.vstack([P, P[:1]]), axis=0).T)
    s = np.concatenate([[0.0], np.cumsum(d)])
    n = max(16, int(round(s[-1] / step)))
    t = np.arange(n) * s[-1] / n
    Q = np.vstack([P, P[:1]])
    return np.column_stack([np.interp(t, s, Q[:, 0]), np.interp(t, s, Q[:, 1])])


def smooth_outline(mask, grid, o):
    """Smooth closed outline of a node mask: the 0.5 level of the mask after a Gaussian blur (sigma outline_sigma), which removes
    the grid's stair-steps and keeps straight edges where they were; then points every outline_step along it, smoothed further
    only if a vertex still turns by more than outline_max_turn. Returns a shapely polygon."""
    import contourpy
    from shapely.geometry import Polygon
    g = ndimage.gaussian_filter(mask.astype(float), o['outline_sigma'] / grid.p)
    loops = [np.asarray(l) for l in contourpy.contour_generator(x=grid.X.T, y=grid.Y.T, z=g.T).lines(0.5) if len(l) > 8]
    loop = max(loops, key=lambda l: Polygon(l).area)
    if np.allclose(loop[0], loop[-1]):
        loop = loop[:-1]
    P = _resample(loop, o['outline_step'])
    k = 0
    while _turns(P).max() > o['outline_max_turn'] and k < 12:
        k += 1
        P = np.column_stack([ndimage.gaussian_filter1d(P[:, 0], 2.0 * k, mode='wrap'), ndimage.gaussian_filter1d(P[:, 1], 2.0 * k, mode='wrap')])
        P = _resample(P, o['outline_step'])
    return Polygon(P)


def _opened(g, r):
    """g with its convex corners rounded to radius r (erode, then grow back with round joins of 5.6 degree steps)."""
    return g.buffer(-r, quad_segs=16).buffer(r, quad_segs=16)


def outlines(foot, grid, o):
    """The plan outlines of tray and pad as smooth curves (second styling pass, SPEC section 11 SF1).
    One curve is taken from the grid: the tray's outer wall (hand outline grown by tray_margin + rim_t). The inner face of the rim
    and the pad's edge are inward offsets of it, so the rim is rim_t wide everywhere and the pad keeps pad_clear from the rim.
    The open rear edge is the straight line x = rear_edge_x; its corners are rounded."""
    from shapely.geometry import box as sbox
    rear = IFACE['rear_edge_x']
    outer_mask = ndimage.binary_dilation(foot, iterations=grid.it(o['tray_margin'] + o['rim_t']))
    outer = smooth_outline(outer_mask, grid, o).buffer(-grid.p / 2, quad_segs=16)      # the half level lies half a cell outside the outermost nodes; the grid-built wall stood on them
    half = sbox(rear, grid.y0 - 50, grid.x0 + grid.p * grid.nx + 50, grid.y0 + grid.p * grid.ny + 50)
    inner = _opened(outer.buffer(-o['rim_t'], quad_segs=16), 1.5)       # the inward offset can leave a corner where the outer wall turns tightly; rounded
    plate = _opened(outer.intersection(half), o['rear_corner'])
    band = plate.difference(inner).difference(sbox(rear - 50, grid.y0 - 50, rear + o['rim_t'] + 0.3, grid.y0 + grid.p * grid.ny + 50))   # no rim across the open rear edge
    band = _opened(band, 0.9)                             # rim ends rounded in plan
    pad = _opened(outer.buffer(-(o['rim_t'] + o['pad_clear']), quad_segs=16).intersection(half), 2.0)
    big = lambda g: max(getattr(g, 'geoms', [g]), key=lambda q: q.area)
    return dict(plate=big(plate), band=big(band), pad=big(pad), inner=inner)


def _rings(g):
    out = []
    for q in getattr(g, 'geoms', [g]):
        if q.is_empty or q.area < 1e-6:
            continue
        out.append(np.asarray(q.exterior.coords)[:-1])
        out += [np.asarray(h.coords)[:-1] for h in q.interiors]
    return out


def slab(g, z0, z1):
    """Shapely (multi)polygon extruded from z0 to z1."""
    r = _rings(g)
    if not r or z1 - z0 <= 1e-9:
        return M()
    return m3.CrossSection([q.tolist() for q in r], m3.FillRule.EvenOdd).extrude(z1 - z0).translate([0, 0, z0])


def pad_top(env, foot, grid, o, floor, bar=None):
    """Height of the pad's top surface at every node, the outline of the pad, and the raised zone."""
    env_e = ndimage.minimum_filter(env, size=3)          # lowest skin within one node all round: the surface between nodes stays below the skin
    rear = IFACE['rear_edge_x']
    cap = o['zone_z'] + o['zone_cap']
    zone = foot & (env_e < cap)
    zone_d = ndimage.binary_dilation(zone, iterations=grid.it(o['zone_margin']))
    outline = ndimage.binary_dilation(foot, iterations=grid.it(o['pad_margin'])) & (grid.X >= rear)
    follow = np.minimum(slope_limited(env_e - o['gap'], grid, o['pad_slope_deg']), cap)
    top = np.where(zone_d, follow, floor + o['base_t'])
    if bar is not None:
        c, u, r = np.array(bar['centre']), np.array(bar['direction']), bar['r']
        dx, dy = grid.X - c[0], grid.Y - c[1]
        s, d = dx * u[0] + dy * u[1], np.abs(-dx * u[1] + dy * u[0])
        inside = (d < r) & (s > bar['s0']) & (s < bar['s1'])
        top = np.where(inside, np.maximum(top, c[2] + np.sqrt(np.maximum(r * r - d * d, 0.0))), top)
    top = np.minimum(top, env_e - o['gap'])
    return top, outline, zone_d


def lip_boxes(floor):
    L = IFACE['lip_head_clearance']
    return [box(L['x'], (s * L['abs_y'][0], s * L['abs_y'][1]) if s > 0 else (-L['abs_y'][1], -L['abs_y'][0]), (floor - 0.01, floor + L['height_above_plate'])) for s in (1, -1)]


def build_pad(top, outline, grid, floor, poly=None):
    """poly: the pad's smooth plan outline (outlines()['pad']). The height field is then built a little wider than the outline
    and cut to it, so the side wall is a smooth upright surface; the top surface is the same height field as without poly."""
    if poly is not None:
        wide = ndimage.binary_dilation(outline, iterations=grid.it(2.0)) & (grid.X >= IFACE['rear_edge_x'])
        v, f = prism(grid.x0, grid.y0, grid.p, top, floor, largest_component(grid.cells(wide)))
        pad = to_manifold(v, f) ^ slab(poly, floor - 1.0, floor + 200.0)
        cells = largest_component(grid.cells(outline))
    else:
        cells = largest_component(grid.cells(outline))
        v, f = prism(grid.x0, grid.y0, grid.p, top, floor, cells)
        pad = to_manifold(v, f)
    for b in lip_boxes(floor):
        pad = pad - b
    return pad, cells


def build_tray(foot, grid, o, floor, polys=None):
    zs = -IFACE['seat_drop']
    rear = IFACE['rear_edge_x']
    inner = ndimage.binary_dilation(foot, iterations=grid.it(o['tray_margin'])) & (grid.X >= rear)
    outer = ndimage.binary_dilation(foot, iterations=grid.it(o['tray_margin'] + o['rim_t'])) & (grid.X >= rear)
    if polys is None:                                   # the grid-stepped tray of the first release
        ring = outer & ~inner
        ring &= ~((grid.X < rear + o['rim_t'] + 0.3) & ndimage.binary_dilation(inner, iterations=2))    # no rim across the open rear edge
        top = np.where(ring, zs + o['rim_h'], floor)
        ear = ring & (np.abs(grid.X - o['ear_x']) <= o['ear_half_len'])
        top = np.where(ear, zs + o['ear_h'], top)
        cells = largest_component(grid.cells(outer))
        v, f = prism(grid.x0, grid.y0, grid.p, top, zs, cells)
        tray = to_manifold(v, f)
    else:
        # smooth outlines: the plate is the plate outline extruded; rim and ears are a height field on a 0.25 mm grid, cut to the
        # rim's outline so that their walls are smooth upright surfaces. The height field rounds both top edges of rim and ears
        # (radius rim_round, from the distance to the wall) and the ears' corners seen from the side (ear_corner).
        import shapely
        band, r, R, q = polys['band'], o['rim_round'], o['ear_corner'], 0.25
        rim_top, ear_top, half = zs + o['rim_h'], zs + o['ear_h'], o['ear_half_len']
        x0, y0, x1, y1 = band.bounds
        gx, gy = np.arange(x0 - 1.0, x1 + 1.0 + q, q), np.arange(y0 - 1.0, y1 + 1.0 + q, q)
        X, Y = np.meshgrid(gx, gy, indexing='ij')
        edge = np.concatenate([np.asarray(shapely.segmentize(ring, 0.05).coords) for g in getattr(band, 'geoms', [band]) for ring in [g.exterior] + list(g.interiors)])
        near = ndimage.binary_dilation(shapely.contains_xy(band, X, Y), iterations=3)
        t = np.zeros(X.shape)
        t[near] = cKDTree(edge).query(np.column_stack([X[near], Y[near]]))[0]          # distance to the rim's wall, mm
        rise = np.sqrt(np.maximum(r * r - (r - np.minimum(t, r)) ** 2, 0.0))            # a quarter circle of radius r starting at the wall
        dx = np.abs(X - o['ear_x'])
        E = np.where(dx <= half - R, ear_top,
            np.where(dx <= half, ear_top - R + np.sqrt(np.maximum(R * R - (dx - (half - R)) ** 2, 0.0)),
            np.where(dx <= half + R, rim_top + R - np.sqrt(np.maximum(R * R - (half + R - dx) ** 2, 0.0)), -1e3)))
        top = np.maximum(rim_top - r + rise, np.minimum(E, ear_top - r + rise))
        cells = near[:-1, :-1] & near[1:, :-1] & near[:-1, 1:] & near[1:, 1:]
        v, f = prism(gx[0], gy[0], q, top, zs + 0.5, cells)
        # the rim starts inside the plate (0.5 mm above its underside) and its wall stands 0.01 mm inside the plate's wall, so that
        # the two solids overlap in volume and share no face: their union is then one clean closed body
        tray = slab(polys['plate'], zs, floor) + (to_manifold(v, f) ^ slab(band.buffer(-0.01, quad_segs=16), zs, zs + 100.0))
    ld = lambda n: to_manifold(*(lambda t: (t.vertices, t.faces))(trimesh.load(os.path.join(HERE, 'interface', n))))
    tray = tray + ld(IFACE['add'])
    for n in IFACE['cut']:
        tray = tray - ld(n)
    for b in lip_boxes(floor):
        tray = tray - b
    # strap slots through both ears: 27 mm wide, roof with 45 degree corners so that the flat bridge is slot_flat = 19 mm (SPEC R12: 20 mm
    # at most). Where an ear crosses the slot at an angle, the bridge along the ear is longer than the flat; the ScanFit option sets a
    # shorter flat and a taller ear for that (SPEC section 21).
    xe, zb = o['ear_x'], zs + o['rim_h'] + 1.5
    hf = o.get('slot_flat', 19.0) / 2; zr_ = zb + 0.7 + (13.5 - hf)
    prof = np.array([[xe - 13.5, zb], [xe + 13.5, zb], [xe + 13.5, zb + 0.7], [xe + hf, zr_], [xe - hf, zr_], [xe - 13.5, zb + 0.7]])
    slot = m3.CrossSection([prof]).extrude(400.0).transform([[1, 0, 0, 0], [0, 0, 1, -200.0], [0, 1, 0, 0]])
    if slot.volume() < 1:                               # the transform mirrors the solid; rebuild with the other winding
        slot = m3.CrossSection([prof[::-1]]).extrude(400.0).transform([[1, 0, 0, 0], [0, 0, 1, -200.0], [0, 1, 0, 0]])
    tray = tray - slot
    # lightening holes through the plate, clear of the rim and of the arm interface
    safe = ndimage.binary_erosion(inner, iterations=grid.it(o['hole_d'] / 2 + 3.0))
    holes, row = [], 0
    y = grid.y0
    while y < grid.y0 + grid.p * grid.ny:
        x = grid.x0 + (o['hole_pitch'] / 2 if row % 2 else 0.0)
        while x < grid.x0 + grid.p * grid.nx:
            i, j = grid.index(np.array([[x, y]]))
            if safe[i[0], j[0]] and not (x < 36.0 and abs(y) < 22.0):
                holes.append(M.cylinder(6.0, o['hole_d'] / 2, o['hole_d'] / 2, 32).translate([x, y, zs - 1.0]))
            x += o['hole_pitch']
        y += o['hole_pitch'] * np.sqrt(3) / 2
        row += 1
    if holes:
        tray = tray - M.batch_boolean(holes, m3.OpType.Add)
    return tray, outer, dict(holes=len(holes), ear_x=xe, strap_slot_z=[zb, zr_], strap_slot_flat_mm=2 * hf)


def build_strap_pad(mesh, o):
    """Flat TPU pad that lies under the hand strap: as long as the back of the hand is round at the strap, two slits for the strap."""
    w, t = o['strap_pad']
    sec = mesh.section(plane_origin=[o['ear_x'], 0, 0], plane_normal=[1, 0, 0])
    P = np.concatenate([e for e in sec.discrete])[:, 1:]
    ys = np.arange(P[:, 0].min(), P[:, 0].max(), 1.0)
    zt = np.array([P[np.abs(P[:, 0] - y) < 1.5][:, 1].max() for y in ys])
    arc = float(np.hypot(np.diff(ys), np.diff(zt)).sum())
    L = round(arc + 30.0, 1)
    pad = box((0, L), (0, w), (0, t))
    for x in (8.0, L - 11.0):
        pad = pad - box((x, x + 3.0), ((w - 27.0) / 2, (w + 27.0) / 2), (-1, t + 1))
    return pad, dict(length=L, width=w, thickness=t, dorsal_arc_at_strap_mm=round(arc, 1))


def stats(d):
    d = np.asarray(d)
    if len(d) == 0:
        return dict(n=0)
    q = np.percentile(d, [5, 25, 50, 75, 95])
    return dict(n=int(len(d)), min=round(float(d.min()), 3), p05=round(float(q[0]), 3), p25=round(float(q[1]), 3), p50=round(float(q[2]), 3),
                p75=round(float(q[3]), 3), p95=round(float(q[4]), 3), max=round(float(d.max()), 3),
                share_le_0p5=round(float((d <= 0.5).mean()), 4), share_le_1p0=round(float((d <= 1.0).mean()), 4), share_le_3p0=round(float((d <= 3.0).mean()), 4))


class Scorer:
    """Scores a pad (any closed mesh in the device frame) against hand scans (SPEC A5, A6c)."""
    def __init__(self, pad_tm, grid, outline, zone_z=-5.0):
        self.grid, self.outline, self.zone_z = grid, outline, zone_z
        self.pad = pad_tm
        dense = pad_tm.subdivide()                                  # surface points at most about 0.18 mm apart for the nearest-point distance
        self.tree = cKDTree(np.concatenate([dense.vertices, dense.triangles_center]))
        i, j = grid.index(pad_tm.vertices)                          # pad surface as a height field (its own vertices), for vertical gaps
        self.top = np.full((grid.nx, grid.ny), -np.inf)
        np.maximum.at(self.top, (i, j), pad_tm.vertices[:, 2])
        self.man = to_manifold(pad_tm.vertices, pad_tm.faces)

    def zone_of(self, V):
        """Contact zone of a scan as placed: vertices below zone_z inside the tray outline (SPEC A5). The zone belongs to the skin:
        when the hand is then moved, the same vertices are scored."""
        i, j = self.grid.index(V)
        return (V[:, 2] < self.zone_z) & self.outline[i, j]

    def penetration(self, V):
        """Deepest vertical penetration of the scan into the pad, mm (0 if none)."""
        i, j = self.grid.index(V)
        over = np.isfinite(self.top[i, j])
        return round(float(max(0.0, (self.top[i, j] - V[:, 2])[over].max())), 3) if over.any() else 0.0

    def score(self, V, faces=None, settle=False, zone=None):
        """V: scan vertices in the device frame. settle: move the hand straight up or down until it just touches the pad.
        zone: boolean mask of the contact-zone vertices; by default the zone of V as given."""
        if zone is None:
            zone = self.zone_of(V)
        i, j = self.grid.index(V)
        over = np.isfinite(self.top[i, j])
        vg = V[:, 2] - self.top[i, j]                               # vertical gap to the pad surface under each vertex
        shift = 0.0
        if settle and over.any():
            shift = -float(vg[over].min())
            V = V + [0, 0, shift]
            vg = vg + shift
        d = self.tree.query(V[zone])[0]
        low = np.full(self.top.shape, np.inf)
        np.minimum.at(low, (i[zone], j[zone]), V[zone, 2])
        visible = V[zone, 2] <= low[i[zone], j[zone]] + 0.5         # zone skin that faces the pad (lowest skin in its column)
        out = dict(zone=stats(d), zone_facing_pad=stats(d[visible]), vertical_gap_under_zone=stats(vg[zone & over]),
                   deepest_penetration_mm=round(float(max(0.0, -vg[over].min())) if over.any() else 0.0, 3),
                   zone_area_share_over_pad=round(float((zone & over).sum() / max(zone.sum(), 1)), 4), settle_shift_mm=round(shift, 3))
        if faces is not None:
            out['overlap_mm3'] = round(float((self.man ^ to_manifold(V, faces)).volume()), 3)
        return out
