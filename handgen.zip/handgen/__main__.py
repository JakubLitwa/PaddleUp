"""PaddleUp v4 hand generator.

  python -m handgen build    --scan hand.stl [--frame frame.json] --out DIR [--hand L|R] [--pitch-offset deg] [--yaw-offset deg] [--grip fitted | scanfit]
  python -m handgen generic  --scan hand.stl [--frame frame.json] --out DIR      generic pad from five caliper numbers, scored on the same scan, with the robustness sweep
  python -m handgen evaluate --pad pad.stl --scan hand.stl [--frame frame.json] --build DIR     score any pad against any scan (held-out scans)
  python -m handgen arm      --scan arm_and_hand.stl --out arm.json              forearm numbers for the Fusion model

`build` writes tray, pad and strap pad (device frame and print orientation), report.json, report.md and gap_map.png."""
import argparse, json, os, sys, hashlib
import numpy as np
from scipy import ndimage
import trimesh
from . import __version__
from .frame import frame_from_json, frame_from_cap, to_device
from .measure import wrist_and_hand, curl_cylinder
from . import build as B
from .generic import build_generic
from .armfit import find_wrist, arm_parameters


def load_device(a):
    mesh = trimesh.load(a.scan, force='mesh')
    R, o, info = frame_from_json(a.frame) if a.frame else frame_from_cap(mesh)
    dev = to_device(mesh, R, o, getattr(a, 'hand', 'L'), getattr(a, 'pitch_offset', 0.0), getattr(a, 'yaw_offset', 0.0))
    pose = hand_pose(a)
    if pose is not None:                                              # release 4.3: the hand placed by a rigid move in the device frame
        dev.apply_transform(pose)
        info = dict(info, hand_pose_in_device_frame=np.round(pose, 6).tolist())
    return dev, info


def hand_pose(a):
    """4 x 4 matrix from --pose FILE (a JSON file with "matrix"), or ScanFit's posture when --grip scanfit is given without --pose."""
    f = getattr(a, 'pose', None)
    if f == 'scanfit':
        from . import scanfit as SF
        return SF.pose_matrix()
    if f:
        return np.array(json.load(open(f))['matrix'], float)
    if getattr(a, 'grip', None) == 'scanfit':
        from . import scanfit as SF
        return SF.pose_matrix()
    return None


def export(man_or_tm, path, drop=False):
    t = man_or_tm if isinstance(man_or_tm, trimesh.Trimesh) else B.to_trimesh(man_or_tm)
    if drop:
        t = t.copy()
        t.apply_translation([0, 0, -t.bounds[0][2]])
    t.export(path)
    r = trimesh.load(path)                      # SPEC section 21: as written (float32), a few triangles can collapse to zero area and leave the
    if not r.is_watertight:                     # mesh open (the ScanFit tray); drop them, close the gap and write the file again
        r.update_faces(r.nondegenerate_faces(height=1e-7)); r.remove_unreferenced_vertices(); r.merge_vertices()
        trimesh.repair.fill_holes(r)
        if r.is_watertight:
            r.export(path)
    return t


def mirror_y(t):
    return trimesh.Trimesh(t.vertices * [1, -1, 1], t.faces[:, ::-1], process=False)


def sha(path):
    return hashlib.sha256(open(path, 'rb').read()).hexdigest()[:16]


def gap_figure(path, grid, cells, top, env, title):
    """Contact map of the pad: vertical gap between the pad surface and the lowest scanned skin over it. Only the pad is drawn:
    its outline, and grey over all of it where nothing rests within 5 mm (so the figure does not trace the hand)."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    nodes = np.zeros(top.shape, bool)
    nodes[:-1, :-1] |= cells; nodes[1:, :-1] |= cells; nodes[:-1, 1:] |= cells; nodes[1:, 1:] |= cells
    gap = np.where(nodes, np.where(np.isfinite(env), env - top, 99.0), np.nan)
    fig, ax = plt.subplots(figsize=(8.5, 6))
    ext = [grid.x0, grid.x0 + grid.p * (grid.nx - 1), grid.y0, grid.y0 + grid.p * (grid.ny - 1)]
    cmap = plt.get_cmap('viridis_r').copy(); cmap.set_over('#dddddd')
    im = ax.imshow(gap.T, origin='lower', extent=ext, vmin=0, vmax=5, cmap=cmap, interpolation='nearest')
    ax.contour(grid.X, grid.Y, nodes.astype(float), levels=[0.5], colors='k', linewidths=0.8)
    ax.set_xlim(-5, grid.X[nodes].max() + 5); ax.set_ylim(grid.Y[nodes].min() - 5, grid.Y[nodes].max() + 5)
    ax.set_aspect('equal'); ax.set_xlabel('X, forearm to fingers (mm)'); ax.set_ylabel('Y (mm), thumb side negative')
    ax.set_title(title, fontsize=10)
    fig.colorbar(im, ax=ax, extend='max', label='gap between pad and skin (mm); grey: pad with nothing resting within 5 mm')
    fig.tight_layout(); fig.savefig(path, dpi=120); plt.close(fig)


def cmd_build(a):
    o = dict(B.DEFAULTS)
    dev, finfo = load_device(a)
    os.makedirs(os.path.join(a.out, 'print'), exist_ok=True)
    # Seat. The arm and the paddle parts are the same for every user (tray underside 25 mm below the forearm axis), so a hand
    # whose lowest skin would leave less than pad_min_t of TPU is not refused: it is raised (moved along +Z) by what is missing,
    # up to --max-lift. Its lowest point then rests on exactly pad_min_t of TPU.
    env0, _ = B.lower_envelope(dev, B.Grid(dev.bounds[0], dev.bounds[1], o['pitch']))
    need_exact = float(-np.nanmin(np.where(np.isfinite(env0), env0, np.nan)) + o['gap'] + o['pad_min_t'] + B.IFACE['tray_t'])
    need0 = round(need_exact, 2)
    lift = 0.0 if a.no_lift else max(0.0, float(np.ceil((need_exact - B.IFACE['seat_drop']) * 100 - 1e-9) / 100))     # rounded up to 0.01 mm
    if lift > a.max_lift and not a.force:
        sys.exit(f"handgen: this hand would have to be raised {lift} mm above its scanned height over the forearm axis to keep {o['pad_min_t']} mm of TPU under it; "
                 f"the limit is {a.max_lift} mm (--max-lift). Nothing was built. Rescan with the wrist higher, or use --pitch-offset; --force builds with the limit.")
    lift = min(lift, a.max_lift)
    if lift > 0:
        dev.apply_translation([0, 0, lift])
    meas = wrist_and_hand(dev)
    curl = curl_cylinder(dev)
    grid = B.Grid(dev.bounds[0], dev.bounds[1], o['pitch'])
    env, foot = B.lower_envelope(dev, grid)
    floor = -(B.IFACE['seat_drop'] - B.IFACE['tray_t'])
    band = a.zone_band
    foot_o = foot
    if a.grip == 'scanfit':
        from . import scanfit as SF
        so = dict(SF.SCANFIT_DEFAULTS)
        for k in ('size', 'fit'):
            if getattr(a, 'grip_' + k) is not None:
                so['sf_' + k] = getattr(a, 'grip_' + k)
        band = so['sf_zone_band'] if band is None else band
        foot_o = foot | SF.bar_plan(so['sf_size'], grid)              # pad and tray reach round the bar where it stands out past the hand
        o['ear_x'] = so['sf_ear_x']                                   # the strap where ScanFit has it
        o['slot_flat'], o['ear_h'] = so['sf_slot_flat'], so['sf_ear_h']   # SPEC section 21: the slot's bridge along the slanted ear
    if band is not None:                                              # the pad follows skin up to this far above the lowest skin (default: a fixed height, zone_z)
        o['zone_z'] = round(float(np.nanmin(np.where(np.isfinite(env), env, np.nan))) + band, 2)
    bar = B.bar_from_curl(curl, foot, grid, o)
    top, outline, zone_d = B.pad_top(env, foot_o, grid, o, floor, bar)
    polys = None if a.stepped else B.outlines(foot_o, grid, o)          # smooth plan outlines (second styling pass); --stepped gives the grid outlines of 1.0
    grip, extras, view = None, [], None
    if a.grip == 'fitted':                                            # release 4.2: the round bar becomes a bar shaped by the scanned hand (grip.py)
        from . import grip as GR
        go = dict(GR.GRIP_DEFAULTS)
        for k in ('swell', 'ball', 'gap', 'sigma', 'fillet', 'cover', 'slack', 'slope'):
            if getattr(a, 'grip_' + k) is not None:
                go['grip_' + k] = getattr(a, 'grip_' + k)
        top_bar = top
        top_f, grip = GR.fitted_grip(dev, grid, B.pad_top(env, foot, grid, o, floor, None)[0], outline, floor, curl, go, env_e=env, pad_gap=o['gap'])
        aux = grip.pop('_aux', None)
    if a.grip == 'scanfit':                                           # release 4.3: ScanFit's posture and ScanFit's bar (scanfit.py)
        from . import grip as GR
        go = dict(GR.GRIP_DEFAULTS)
        top_bar = top
        top_f, solids, grip = SF.scanfit_grip(dev, grid, B.pad_top(env, foot_o, grid, o, floor, None)[0], outline, floor, so, env, pad_gap=o['gap'], base_t=o['base_t'])
        aux = grip.pop('_aux', None)
        # the bar, its keel, its web with its foot and (fitted variant) its rise: solids joined to the height field
        for sd in solids:
            if 'slabs' in sd:
                m = B.M()
                for poly, z0, z1 in sd['slabs']:
                    m = m + B.slab(poly, z0, z1)
            else:
                m = B.to_manifold(sd['v'], sd['f'])
                if sd.get('clip') is not None:
                    m = m ^ B.slab(sd['clip'], floor - 1.0, floor + 200.0)
            extras.append(m)
        grip['solids_joined_to_the_pad'] = {sd['name']: round(float(m.volume()) / 1000, 3) for sd, m in zip(solids, extras)}
        view = aux['view']
    def whole(t):
        m = B.build_pad(t, outline, grid, floor, None if polys is None else polys['pad'])
        for x in extras:
            m = (m[0] + x, m[1])
        return m
    if a.grip in ('fitted', 'scanfit'):
        if top_f is not None:
            top = top_f
            pad_bar = B.to_trimesh(B.build_pad(top_bar, outline, grid, floor, None if polys is None else polys['pad'])[0])
            hand_solid, top0 = B.to_manifold(dev.vertices, dev.faces), aux['top0']
            grip['rounds_against_the_scan_as_a_solid'] = []
            for _ in range(12):                                       # the exact solids must not overlap at all (SPEC A5)
                both = whole(top)[0] ^ hand_solid
                vol = float(both.volume())
                grip['rounds_against_the_scan_as_a_solid'].append(round(vol, 6))
                if vol <= 0:
                    break
                top = GR.give_way(top, grid, np.asarray(both.to_mesh().vert_properties)[:, :2], 0.15, go['grip_dimple'], floor_top=top0)
    pad, cells = whole(top)
    tray, tray_outline, tinfo = B.build_tray(foot_o, grid, o, floor, polys)
    if polys is not None:
        tinfo['outline'] = {k: dict(points=len(g.exterior.coords) - 1, largest_turn_deg=round(float(B._turns(np.asarray(g.exterior.coords)[:-1]).max()), 2), area_mm2=round(g.area, 1)) for k, g in polys.items()}
    strap, sinfo = B.build_strap_pad(dev, o)
    flip = (lambda t: mirror_y(t)) if a.hand == 'R' else (lambda t: t)
    files = {}
    for name, man, mat in (('pad', pad, 'TPU'), ('tray', tray, 'PETG'), ('strap_pad', strap, 'TPU')):
        t = flip(B.to_trimesh(man))
        export(t, os.path.join(a.out, f'{name}.stl'))
        p = os.path.join(a.out, 'print', f'PaddleUp_v4_{name}_{mat}.stl')
        export(t, p, drop=True)
        files[name] = dict(volume_cm3=round(float(t.volume) / 1000, 3), closed=bool(t.is_watertight), bodies=int(t.body_count),
                           size_mm=np.round(t.extents, 1).tolist(), sha256_16=sha(p), triangles=int(len(t.faces)))
    np.savez_compressed(os.path.join(a.out, 'grid.npz'), x0=grid.x0, y0=grid.y0, p=grid.p, nx=grid.nx, ny=grid.ny, tray_outline=tray_outline, pad_cells=cells, top=(top if view is None else view).astype(np.float32))
    pad_tm = B.to_trimesh(pad)
    sc = B.Scorer(pad_tm, grid, tray_outline, o['zone_z'])
    score = sc.score(dev.vertices, dev.faces)
    tray_overlap = float((tray ^ B.to_manifold(dev.vertices, dev.faces)).volume())
    lowest = float(np.nanmin(np.where(np.isfinite(env), env, np.nan)))
    L = B.IFACE['lip_head_clearance']
    lipz = (grid.X >= L['x'][0]) & (grid.X <= L['x'][1]) & (np.abs(grid.Y) >= L['abs_y'][0]) & (np.abs(grid.Y) <= L['abs_y'][1]) & outline
    r_tip = meas['farthest_point_from_wrist_mm']
    z5 = score['zone']
    rep = dict(generator=f'handgen {__version__}', hand=a.hand, options=o, wrist_offsets_deg=dict(pitch=a.pitch_offset, yaw=a.yaw_offset),
               frame=dict(finfo, note='The forearm is not in this scan: X is the normal of the wrist cap. A frame error of 1 degree moves the fingertips by '
                          f'{r_tip * np.pi / 180:.2f} mm (arc length = radius x angle, radius {r_tip} mm). Use --pitch-offset and --yaw-offset to rebuild for another wrist posture.'),
               measurements=meas, curl_cylinder=curl, grip_bar=bar,
               seat=dict(seat_drop_used=B.IFACE['seat_drop'], pad_floor_z=floor, seat_drop_needed_as_scanned=need0, lift_applied_mm=lift, max_lift_mm=a.max_lift,
                         lift_note='The hand is raised by lift_applied_mm along +Z before the pad is shaped, so that its lowest point rests on pad_min_t of TPU. '
                                   'All numbers in this report are for the raised hand.', lowest_skin_z=round(lowest, 2),
                         pad_thickness_under_lowest_skin=round(lowest - o['gap'] - floor, 2), seat_drop_needed=round(-lowest + o['gap'] + o['pad_min_t'] + B.IFACE['tray_t'], 2),
                         ok=bool(lowest - o['gap'] - floor >= o['pad_min_t'] - 1e-6)),
               pad_over_arm_lips=dict(least_tpu_thickness_mm=round(float((top[lipz] - (floor + L['height_above_plate'])).min()), 2) if lipz.any() else None),
               fit_A5=dict(zone='scan vertices below Z -5 mm inside the tray outline; gap = distance from each vertex to the nearest point of the pad surface',
                           overlap_pad_vs_scan_mm3=score['overlap_mm3'], overlap_tray_vs_scan_mm3=round(tray_overlap, 3), gap=z5,
                           gap_of_skin_facing_the_pad=score['zone_facing_pad'], vertical_gap=score['vertical_gap_under_zone'],
                           targets=dict(no_overlap=score['overlap_mm3'] == 0 and tray_overlap == 0, median_le_1mm=z5['p50'] <= 1.0, p95_le_3mm=z5['p95'] <= 3.0),
                           note='The pad is shaped from this same scan, so it fits it by construction; see the generic pad and the sweep for what that is worth.'),
               tray=tinfo, strap_pad=sinfo, files=files)
    if grip is not None:
        rep['scanfit_grip' if a.grip == 'scanfit' else 'fitted_grip'] = grip
        if grip['built']:
            near = ndimage.binary_dilation(aux['foot'], iterations=grid.it(3.0))
            grip['skin_contact'] = dict(
                note='Scanned skin that faces the pad (inside the pad outline, normal pointing down, lowest skin in its grid column) and lies within the given distance of the pad surface. '
                     'Both pads are shaped from this same scan; see the generic pad and a second scan for what that is worth.',
                under_the_whole_hand=dict(fitted_grip=GR.skin_contact(pad_tm, dev, grid, outline), round_bar=GR.skin_contact(pad_bar, dev, grid, outline)),
                over_the_grip=dict(fitted_grip=GR.skin_contact(pad_tm, dev, grid, outline, near), round_bar=GR.skin_contact(pad_bar, dev, grid, outline, near),
                                   zone='nodes within 3 mm of the fitted grip, in plan'))
            grip['overlap_round_bar_pad_vs_scan_mm3'] = round(float((B.to_manifold(pad_bar.vertices, pad_bar.faces) ^ B.to_manifold(dev.vertices, dev.faces)).volume()), 3)
    rep['fit_A5']['pass'] = bool(all(rep['fit_A5']['targets'].values()))
    if not rep['seat']['ok'] and not a.force:
        sys.exit(f"handgen: this hand needs a seat {rep['seat']['seat_drop_needed']} mm below the forearm axis, but the arm and the paddle group are built for "
                 f"{B.IFACE['seat_drop']} mm, and raising the hand is switched off (--no-lift). Nothing was reported as built; --force writes the report anyway.")
    json.dump(rep, open(os.path.join(a.out, 'report.json'), 'w'), indent=1)
    gap_figure(os.path.join(a.out, 'gap_map.png'), grid, cells, top if view is None else view, env, f'Scan-built pad, contact map (contact zone: median {z5["p50"]:.2f} mm, 95 % below {z5["p95"]:.2f} mm)')
    md = [f'# Hand generator report ({rep["generator"]}, hand {a.hand})', '',
          '| Quantity | Value |', '|---|---|',
          f'| Frame | {finfo["source"]} |', f'| Fingertip movement per degree of frame error | {r_tip * np.pi / 180:.2f} mm |',
          f'| Wrist width x thickness, tape girth | {meas["wrist_width_mm"]} x {meas["wrist_thickness_mm"]} mm, {meas["wrist_girth_tape_mm"]} mm |',
          f'| Hand length beyond the wrist, width | {meas["hand_length_beyond_wrist_mm"]} mm, {meas["hand_width_mm"]} mm |',
          f'| Curl cylinder | diameter {curl["diameter"]:.1f} mm at {curl["theta_deg"]:.0f} deg, centre {np.round(curl["centre"], 1).tolist()} |',
          f'| Grip bar | diameter {bar["diameter"]:.1f} mm, length {bar["length"]:.0f} mm |' if not (grip and grip['built']) else
          f'| ScanFit bar, size {grip["options"]["sf_size"]}, in ScanFit\'s posture (in place of a round bar of diameter {bar["diameter"]:.1f} mm) | {grip["bar"]["rounded"]["volume_cm3"]} cm3, {grip["bar"]["loft"]["length_mm"]} mm long; '
          f'top {grip["height_over_pad_floor_mm"]:.1f} mm over the pad floor; {100 * grip["bar_surface"]["open_to_the_hand_share"]:.0f} % of its surface open to the hand; '
          f'nearest skin as scanned {grip["bar_to_skin_as_scanned_mm"]["nearest"]:.2f} mm from it; raised toward the skin by at most {grip.get("fit", {}).get("largest_rise_mm", 0.0):.2f} mm |' if a.grip == 'scanfit' else
          f'| Fitted grip (in place of the round bar of diameter {bar["diameter"]:.1f} mm) | balls that fit: diameter {grip["ball_diameter_mm"]["min"]:.1f} to {grip["ball_diameter_mm"]["max"]:.1f} mm over {grip["length_mm"]:.0f} mm; '
          f'bar {grip["bar_diameter_mm"]["min"]:.1f} to {grip["bar_diameter_mm"]["max"]:.1f} mm across, {grip["height_over_pad_floor_mm"]:.1f} mm high over the pad floor; '
          f'{100 * grip["carved_share_of_footprint"]:.0f} % of its plan area carved by the hand; nowhere nearer than {grip["clearance_to_skin_as_scanned_mm"]["min"]:.2f} mm to the skin as scanned |',
          f'| Lowest skin, pad under it | z {lowest:.2f} mm, {lowest - o["gap"] - floor:.2f} mm of TPU (seat needed {rep["seat"]["seat_drop_needed"]} mm, used {B.IFACE["seat_drop"]} mm) |',
          f'| Hand raised above its scanned height | {lift} mm (seat needed as scanned {need0} mm; limit {a.max_lift} mm) |',
          f'| Overlap pad / tray against the scan | {score["overlap_mm3"]} / {tray_overlap:.3f} mm3 |',
          f'| Gap in the contact zone ({z5["n"]} points) | median {z5["p50"]} mm, 95th percentile {z5["p95"]} mm, largest {z5["max"]} mm |',
          f'| Share of the zone within 0.5 mm / 1 mm | {100 * z5["share_le_0p5"]:.1f} % / {100 * z5["share_le_1p0"]:.1f} % |',
          f'| A5 targets (no overlap, median <= 1 mm, 95th <= 3 mm) | {"PASS" if rep["fit_A5"]["pass"] else "FAIL"} |',
          f'| Pad, tray, strap pad volume | {files["pad"]["volume_cm3"]}, {files["tray"]["volume_cm3"]}, {files["strap_pad"]["volume_cm3"]} cm3 |', '',
          rep['fit_A5']['note'], '']
    if grip is not None and not grip['built']:
        md += [f'**Fitted grip not built:** {grip["why"]}. The pad has the round bar.', '']
    if grip is not None and grip['built']:
        cw, cg = grip['skin_contact']['under_the_whole_hand'], grip['skin_contact']['over_the_grip']
        md += ['## ScanFit bar against a round bar, on this scan in the same posture' if a.grip == 'scanfit' else '## Fitted grip against the round bar, on this scan', '',
               '| Skin facing the pad, area within | 0.5 mm | 1 mm | 2 mm | of all such skin |', '|---|---|---|---|---|']
        nm = 'ScanFit bar' if a.grip == 'scanfit' else 'fitted grip'
        for lab, c in ((f'Whole hand, {nm}', cw['fitted_grip']), ('Whole hand, round bar', cw['round_bar']), (f'Over the grip, {nm}', cg['fitted_grip']), ('Over the grip, round bar', cg['round_bar'])):
            md.append(f'| {lab} | {c["within_0p5_mm_mm2"]:.0f} mm2 | {c["within_1p0_mm_mm2"]:.0f} mm2 | {c["within_2p0_mm_mm2"]:.0f} mm2 | {c["skin_facing_the_pad_mm2"]:.0f} mm2 |')
        md += ['', grip['skin_contact']['note'], '']
    open(os.path.join(a.out, 'report.md'), 'w').write('\n'.join(md))
    print('\n'.join(md))


def cmd_generic(a):
    dev, _ = load_device(a)
    rep = json.load(open(os.path.join(a.build, 'report.json')))
    if 'scanfit_grip' in rep:
        sys.exit('handgen: `generic` is not made for a build with --grip scanfit. The generic pad is a pad without a scan, shaped from four numbers; '
                 'the ScanFit bar and posture are placed for one scanned hand. Use `evaluate` to score that build against a scan.')
    pm = rep.get('frame', {}).get('hand_pose_in_device_frame')
    if pm:
        dev.apply_transform(np.array(pm, float))                                # the posture the build was made for
    dev.apply_translation([0, 0, rep['seat'].get('lift_applied_mm', 0.0)])      # the hand as the build placed it
    g = np.load(os.path.join(a.build, 'grid.npz'))
    grid = B.Grid.__new__(B.Grid)
    grid.p, grid.x0, grid.y0, grid.nx, grid.ny = float(g['p']), float(g['x0']), float(g['y0']), int(g['nx']), int(g['ny'])
    grid.X, grid.Y = np.meshgrid(grid.x0 + grid.p * np.arange(grid.nx), grid.y0 + grid.p * np.arange(grid.ny), indexing='ij')
    m = rep['measurements']
    numbers = dict(hand_length=round(m['hand_length_beyond_wrist_mm']), hand_width=round(m['hand_width_mm']), wrist_width=round(m['wrist_width_mm']),
                   wrist_thickness=round(m['wrist_thickness_mm'], 1), curl_diameter=round(rep['curl_cylinder']['diameter'], 1))
    gpad, recipe = build_generic(grid=grid, **numbers)
    os.makedirs(a.out, exist_ok=True)
    gt = export(gpad, os.path.join(a.out, 'generic_pad.stl'))
    st = trimesh.load(os.path.join(a.build, 'pad.stl'))
    if rep['hand'] == 'R':
        st = mirror_y(st)
    outline = g['tray_outline']
    zz = rep.get('options', {}).get('zone_z', B.DEFAULTS['zone_z'])
    scorers = dict(scan_built=B.Scorer(st, grid, outline, zz), generic=B.Scorer(gt, grid, outline, zz))
    V, F = dev.vertices, dev.faces

    def turn(axis, deg):
        t = np.radians(deg); c, s = np.cos(t), np.sin(t)
        R = np.array([[c, 0, -s], [0, 1, 0], [s, 0, c]]) if axis == 'pitch' else np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
        return V @ R.T
    zone = scorers['scan_built'].zone_of(V)          # the contact zone is fixed on the skin as scanned
    cases = [('as scanned', V)]
    for ax, k in (('X', 0), ('Y', 1), ('Z', 2)):
        for d in (-3, -2, -1, 1, 2, 3):
            sh = np.zeros(3); sh[k] = d
            cases.append((f'shift {ax} {d:+d} mm', V + sh))
    for ax in ('pitch', 'yaw'):
        for d in (-5, -2, 2, 5):
            cases.append((f'{ax} {d:+d} deg', turn(ax, d)))
    rows = []
    for name, Vc in cases:
        row = dict(case=name)
        for pn, sc in scorers.items():
            placed = sc.score(Vc, F if name == 'as scanned' else None, zone=zone) if name == 'as scanned' else dict(deepest_penetration_mm=sc.penetration(Vc), zone=dict(p50=None, p95=None))
            rest = sc.score(Vc, settle=True, zone=zone)
            row[pn] = dict(as_placed=dict(deepest_penetration_mm=placed['deepest_penetration_mm'], p50=placed['zone']['p50'], p95=placed['zone']['p95'], overlap_mm3=placed.get('overlap_mm3')),
                           resting=dict(lift_mm=rest['settle_shift_mm'], p50=rest['zone']['p50'], p95=rest['zone']['p95'], share_le_0p5=rest['zone']['share_le_0p5'],
                                        share_le_1p0=rest['zone']['share_le_1p0'], n=rest['zone']['n']))
        rows.append(row)
    # best placement (review R4 F2): let the hand settle wherever each pad suits it best, so that the generic pad is not judged
    # only at the scanned placement. Grid over X and Y -6..+6 mm (3 mm) and yaw -10..+10 deg (5 deg), then one finer pass (1 mm, 2.5 deg).
    def search(sc):
        def val(dx, dy, yw):
            r = sc.score(turn('yaw', yw) + np.array([dx, dy, 0.0]), settle=True, zone=zone)
            return r['zone']['p50'], r
        best = None
        for yw in (-10, -5, 0, 5, 10):
            for dx in range(-6, 7, 3):
                for dy in range(-6, 7, 3):
                    v, r = val(dx, dy, yw)
                    if best is None or v < best[0]:
                        best = (v, dx, dy, yw, r)
        _, bx, by, byw, _ = best
        for yw in (byw - 2.5, byw, byw + 2.5):
            for dx in (bx - 1, bx, bx + 1):
                for dy in (by - 1, by, by + 1):
                    v, r = val(dx, dy, yw)
                    if v < best[0]:
                        best = (v, dx, dy, yw, r)
        v, dx, dy, yw, r = best
        return dict(shift_x_mm=dx, shift_y_mm=dy, yaw_deg=yw, lift_mm=r['settle_shift_mm'], p50=r['zone']['p50'], p95=r['zone']['p95'], share_le_0p5=r['zone']['share_le_0p5'])
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(2) as ex:                       # the two pads side by side
        best_place = dict(zip(scorers, ex.map(search, scorers.values())))
    out = dict(numbers_a_maker_measures=numbers, recipe=recipe, best_placement=best_place,
               best_placement_method='smallest median resting gap over X and Y -6 to +6 mm and yaw -10 to +10 degrees (grid 3 mm and 5 degrees, then 1 mm and 2.5 degrees around the best point)', recipe_text=build_generic.__module__ and sys.modules[build_generic.__module__].__doc__,
               method='as_placed: hand exactly where the case puts it. resting: the hand is then moved straight up or down until it just touches the pad (first contact), '
                      'and the gap is the distance from each contact-zone vertex (below Z -5, inside the tray outline) to the nearest pad point.',
               note='The scan-built pad is scored on the scan it was built from: its "as scanned" row fits by construction. The other rows move the hand, which is the only held-out evidence available without a second scan.',
               generic_pad_volume_cm3=round(float(gt.volume) / 1000, 2), rows=rows)
    json.dump(out, open(os.path.join(a.out, 'generic_vs_scan.json'), 'w'), indent=1)
    lines = ['case                 | scan-built: lift  p50   p95  <=0.5mm | generic: lift  p50   p95  <=0.5mm']
    for r in rows:
        s, gq = r['scan_built']['resting'], r['generic']['resting']
        lines.append(f'{r["case"]:20s} | {s["lift_mm"]:16.2f} {s["p50"]:5.2f} {s["p95"]:5.2f} {100 * s["share_le_0p5"]:6.1f}% | {gq["lift_mm"]:13.2f} {gq["p50"]:5.2f} {gq["p95"]:5.2f} {100 * gq["share_le_0p5"]:6.1f}%')
    if best_place:
        s, gq = best_place['scan_built'], best_place['generic']
        lines.append(f'{"best placement":20s} | {s["lift_mm"]:16.2f} {s["p50"]:5.2f} {s["p95"]:5.2f} {100 * s["share_le_0p5"]:6.1f}% | {gq["lift_mm"]:13.2f} {gq["p50"]:5.2f} {gq["p95"]:5.2f} {100 * gq["share_le_0p5"]:6.1f}%')
        lines.append(f'  best placement found at: scan-built X {s["shift_x_mm"]:+} mm, Y {s["shift_y_mm"]:+} mm, yaw {s["yaw_deg"]:+} deg; generic X {gq["shift_x_mm"]:+} mm, Y {gq["shift_y_mm"]:+} mm, yaw {gq["yaw_deg"]:+} deg')
    open(os.path.join(a.out, 'generic_vs_scan.txt'), 'w').write('\n'.join(lines) + '\n')
    print('\n'.join(lines))
    # figure: median and 95th percentile of the resting gap for every case, both pads (no hand drawn)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axs = plt.subplots(1, 2, figsize=(13, 6), sharey=True)
    y = np.arange(len(rows))
    for ax, key, ttl in ((axs[0], 'p50', 'median gap, hand resting on the pad (mm)'), (axs[1], 'p95', '95th percentile of the gap (mm)')):
        ax.barh(y - 0.2, [r['scan_built']['resting'][key] for r in rows], 0.4, label='pad built from the scan', color='#1f77b4')
        ax.barh(y + 0.2, [r['generic']['resting'][key] for r in rows], 0.4, label='generic pad from caliper numbers', color='#ff7f0e')
        ax.set_title(ttl, fontsize=10); ax.grid(axis='x', alpha=0.3)
    axs[0].set_yticks(y); axs[0].set_yticklabels([r['case'] for r in rows], fontsize=8); axs[0].invert_yaxis(); axs[0].legend(fontsize=8)
    fig.suptitle('Contact-zone gap with the scanned hand moved or turned: scan-built pad against generic pad', fontsize=11)
    fig.tight_layout(); fig.savefig(os.path.join(a.out, 'generic_vs_scan.png'), dpi=120); plt.close(fig)


def cmd_evaluate(a):
    dev, finfo = load_device(a)
    rp = os.path.join(a.build, 'report.json')
    brep = json.load(open(rp)) if os.path.exists(rp) else {}
    lift = brep.get('seat', {}).get('lift_applied_mm', 0.0)
    pm = brep.get('frame', {}).get('hand_pose_in_device_frame')
    if pm and getattr(a, 'pose', None) is None:
        dev.apply_transform(np.array(pm, float))                                # the posture the build was made for
    dev.apply_translation([0, 0, lift])                                         # the hand as the build placed it
    g = np.load(os.path.join(a.build, 'grid.npz'))
    grid = B.Grid.__new__(B.Grid)
    grid.p, grid.x0, grid.y0, grid.nx, grid.ny = float(g['p']), float(g['x0']), float(g['y0']), int(g['nx']), int(g['ny'])
    grid.X, grid.Y = np.meshgrid(grid.x0 + grid.p * np.arange(grid.nx), grid.y0 + grid.p * np.arange(grid.ny), indexing='ij')
    pad = trimesh.load(a.pad)
    sc = B.Scorer(pad, grid, g['tray_outline'], brep.get('options', {}).get('zone_z', B.DEFAULTS['zone_z']))
    out = dict(pad=a.pad, scan=os.path.basename(a.scan), frame=finfo, hand_raised_mm=lift, as_placed=sc.score(dev.vertices, dev.faces), resting=sc.score(dev.vertices, settle=True))
    print(json.dumps(out, indent=1))
    if a.out:
        json.dump(out, open(a.out, 'w'), indent=1)


def cmd_arm(a):
    mesh = trimesh.load(a.scan, force='mesh')
    if a.frame:
        R, o, info = frame_from_json(a.frame)
        dev = to_device(mesh, R, o, a.hand)
        wrist = dict(source='frame file')
    else:
        R, o, info = frame_from_cap(mesh)
        capf = to_device(mesh, R, o, a.hand)
        xw, secs = find_wrist(capf)
        dev = capf.copy(); dev.apply_translation([-xw, 0, 0])
        wrist = dict(source='smallest tape girth between the forearm cap and the hand', distance_from_cap_mm=round(xw, 1))
    presets = {'XS': dict(girth=174.4), 'S': dict(girth=213.3), 'M': dict(girth=233.7), 'L': dict(girth=254.0)}
    out = dict(generator=f'handgen {__version__}', frame=info, wrist=wrist, parameters=arm_parameters(dev, a.fore_dist, presets))
    print(json.dumps(out, indent=1))
    if a.out:
        json.dump(out, open(a.out, 'w'), indent=1)
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(prog='handgen', description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    for name, fn in (('build', cmd_build), ('generic', cmd_generic), ('evaluate', cmd_evaluate), ('arm', cmd_arm)):
        p = sub.add_parser(name)
        p.set_defaults(fn=fn)
        p.add_argument('--scan', required=True); p.add_argument('--frame'); p.add_argument('--hand', choices=['L', 'R'], default='L'); p.add_argument('--out')
        if name == 'build':
            p.add_argument('--pitch-offset', type=float, default=0.0); p.add_argument('--yaw-offset', type=float, default=0.0); p.add_argument('--force', action='store_true')
            p.add_argument('--max-lift', type=float, default=6.0, help='largest raise of the hand above its scanned height, mm'); p.add_argument('--no-lift', action='store_true')
            p.add_argument('--stepped', action='store_true', help='tray and pad outlines on the grid, as in release 1.0 (default: smooth outlines)')
            p.add_argument('--grip', choices=['bar', 'fitted', 'scanfit'], default='bar', help='bar: the round grip bar of release 4.1 (default). fitted: a bar shaped by the scanned hand (release 4.2, grip.py). '
                           'scanfit: the hand in the posture of the ScanFit design, resting on ScanFit\'s P1H bar (release 4.3, scanfit.py)')
            p.add_argument('--pose', default=None, help='JSON file with "matrix" (4 x 4): a rigid move of the hand in the device frame before anything is built; or the word scanfit for the posture of the ScanFit design')
            p.add_argument('--zone-band', type=float, default=None, help='the pad follows skin that lies less than this above the lowest skin, mm (default: a fixed height, zone_z; with --grip scanfit: 18)')
            p.add_argument('--grip-size', type=int, default=None, choices=[76, 83, 88], help='scanfit: which of ScanFit\'s bars (default 76)')
            p.add_argument('--grip-fit', type=float, default=None, help='scanfit: the bar may rise toward the scanned skin by this much, mm (default 0: ScanFit\'s bar as it is)')
            for k, h in (('swell', 'bar radius as a multiple of the largest ball that fits (default 1.15)'), ('ball', 'rolling ball radius, mm (default 6)'), ('gap', 'clearance to the smoothed skin, mm (default 0.3)'),
                         ('sigma', 'smoothing of the skin, mm (default 1.2)'), ('fillet', 'fillet between grip and pad, mm (default 4)'), ('cover', 'how near the skin must be to a ball for its station to count, mm (default 5)'),
                         ('slack', 'sideways room for a hand that lands off its scanned place, mm (default 0.75)'), ('slope', 'slope at which the grip falls away beside steep skin, degrees (default 55)')):
                p.add_argument('--grip-' + k, type=float, default=None, help='fitted grip: ' + h)
        if name in ('generic', 'evaluate'):
            p.add_argument('--build', required=True, help='folder written by `build`')
        if name == 'evaluate':
            p.add_argument('--pad', required=True)
        if name == 'arm':
            p.add_argument('--fore-dist', type=float, default=140.0)
    a = ap.parse_args(argv)
    a.fn(a)


if __name__ == '__main__':
    main()
