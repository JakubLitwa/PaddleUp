"""Device frame of a hand scan. X runs along the forearm toward the hand, Z toward the back of the hand, origin at the wrist section.

The frame comes either from a JSON file (rows of R_rows are device X, Y, Z in file coordinates, plus the origin), or from
the flat patch that scanning software puts over the open wrist end of the scan (the 'cap'): X is the inward normal of the cap,
the origin its centroid, Z its minor axis. The side of Z is taken toward the centroid of the hand beyond 60 mm, because a
relaxed hand is extended toward its back; `dorsal_flip` reverses it."""
import json
import numpy as np


def frame_from_json(path):
    f = json.load(open(path))
    return np.array(f['R_rows'], float), np.array(f['origin_file_mm'], float), dict(source='file ' + path)


def frame_from_cap(mesh, dorsal_flip=False):
    V, N, A, C = mesh.vertices, mesh.face_normals, mesh.area_faces, mesh.triangles_center
    c = V.mean(0)
    _, E = np.linalg.eigh(np.cov((V - c).T))
    best = None
    for axis in (E[:, -1], -E[:, -1]):                  # the cap is at one end of the long axis
        t = (C - c) @ axis
        reg = np.where(t < ((V - c) @ axis).min() + 40.0)[0]
        idx = reg[np.argsort(-A[reg])[:400]]            # largest faces first: a software cap is made of big flat faces
        for i in idx[::8]:
            sup = reg[(N[reg] @ N[i]) > 0.999]
            if best is None or A[sup].sum() > best[0]:
                best = (A[sup].sum(), sup, N[i])
    area, sup, n0 = best
    P = V[np.unique(mesh.faces[sup])]
    pc = P.mean(0)
    _, _, vt = np.linalg.svd(P - pc)
    n = vt[2] if vt[2] @ n0 > 0 else -vt[2]
    x = -n
    Q = (P - pc) - np.outer((P - pc) @ n, n)
    w, E2 = np.linalg.eigh(np.cov(Q.T))
    z = E2[:, 1] - (E2[:, 1] @ x) * x
    z /= np.linalg.norm(z)
    y = np.cross(z, x)
    R = np.vstack([x, y, z])
    d = ((V - pc) @ R.T)
    if (d[d[:, 0] > 60][:, 2].mean() < 0) != dorsal_flip:
        z = -z
        R = np.vstack([x, np.cross(z, x), z])
    res = (P - pc) @ n
    return R, pc, dict(source='wrist cap of the scan', cap_area_mm2=round(float(area), 1), cap_flatness_rms_mm=round(float(np.sqrt((res ** 2).mean())), 4))


def to_device(mesh, R, origin, hand='L', pitch_deg=0.0, yaw_deg=0.0):
    """Copy of the mesh in the device frame. A right hand is mirrored in Y so that the builder always sees a left hand.
    pitch_deg, yaw_deg: wrist offsets (A7): the hand is turned about the wrist origin, pitch about Y (positive = toward the back
    of the hand), yaw about Z (positive = toward the thumb), before anything is built."""
    import trimesh
    V = (mesh.vertices - origin) @ R.T
    F = mesh.faces.copy()
    if hand == 'R':
        V[:, 1] *= -1
        F = F[:, ::-1]
    p, yw = np.radians(pitch_deg), np.radians(-yaw_deg)       # thumb is on -Y
    Ry = np.array([[np.cos(p), 0, -np.sin(p)], [0, 1, 0], [np.sin(p), 0, np.cos(p)]])
    Rz = np.array([[np.cos(yw), -np.sin(yw), 0], [np.sin(yw), np.cos(yw), 0], [0, 0, 1]])
    V = V @ (Rz @ Ry).T
    return trimesh.Trimesh(V, F, process=False)
