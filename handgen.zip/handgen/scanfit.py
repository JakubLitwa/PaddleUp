"""ScanFit ergonomics (handgen 4.3, `build --grip scanfit`): the hand lies as in the user's ScanFit design and closes round ScanFit's P1H bar.

What is taken from ScanFit (scanfit/scanfit.json, scanfit/bars.json and the bar files next to them):
 - the hand's posture: turned 20 degrees toward the back of the hand at the wrist, as the P1H cradle of ScanFit is shaped for;
 - the bar: the loft of P1H_Handle_76 (or 83, 88), at the place it has in ScanFit relative to the hand. Its two end edges are rounded
   (tools/scanfit_bars.py), because the posts that cover them in ScanFit are not there.
The pad and the tray are then built for the hand in that posture by the generator's own rules, with two changes: the pad follows the skin up
to `sf_zone_band` mm above the lowest skin (release 4.1 uses a fixed height), and pad and tray reach round the bar where it stands out past
the hand.

How the bar stands on the pad. In ScanFit the bar is a part of its own, held by a pin at each end, and the hand can close round it: its side
toward the fingertips is open to below, and near the thumb it is open all round. Here bar and pad are one print, so the bar needs something
under it that prints without supports. That is a keel: the least body under the bar whose underside is nowhere flatter than `sf_overhang`
degrees. The bar's own surface is kept down to where it gets flatter than that (about 45 degrees below its widest line); from there the
keel's flat wall runs on, tangent to the bar, toward a web under the middle of the bar. Near the bar the pad's edges fall away at `sf_fall`
degrees (ScanFit's cradle does the same at 45); where such an edge runs in under the bar it joins the keel, so behind the bar the palm pad
and the bar are one, as cradle and bar are in ScanFit.

The keel (function keel). A body prints without supports when each layer lies within a fixed step of the layer below it: with layers h
apart and the steepest allowed overhang a degrees from the horizontal, the step is h / tan(a). Read downward, the layer below must contain
the layer above shrunk by that step. The least body is therefore, at height z, the union over all heights z' >= z of the bar's section at
z' shrunk by (z' - z) / tan(a). A point p of the plan is in it at height z when a disc round p of radius (z' - z) / tan(a) lies in the bar's
section at some z'; so the underside over p is  min over z' of  z' - tan(a) * r(p, z'),  r being the distance from p to the outline of the
section at z'. r comes from a Euclidean distance transform of each section on a grid four times finer than the pad's.
(Shrinking a set by a disc is erosion: J. Serra, Image Analysis and Mathematical Morphology, Academic Press, 1982. The 45 degree rule of
thumb for unsupported overhangs is common slicer practice; PrusaSlicer's "support_material_threshold" is the same angle, and the built pad
is sliced with it in tools/scanfit_checks.py to see that no support is asked for.)

Fitted variant (`sf_fit` > 0). Where the scanned skin lies within reach over the bar, the bar is raised toward it by at most `sf_fit` mm, up
to the limit that the fitted grip uses (grip.py: `grip_gap` off the smoothed skin, 0.2 mm under the skin as scanned, with `grip_slack` of
room sideways and a `grip_slope` fall-away). The rise fades out where the skin is more than `sf_fit` + `sf_fit_reach` away, so the side of
the bar that the fingers close round stays ScanFit's."""
import os, json
import numpy as np
import trimesh
from scipy import ndimage
from . import sdf as SDF
from . import grip as GR
from .hfield import prism

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = json.load(open(os.path.join(HERE, 'scanfit', 'scanfit.json')))
BARS = json.load(open(os.path.join(HERE, 'scanfit', 'bars.json'))) if os.path.exists(os.path.join(HERE, 'scanfit', 'bars.json')) else {}

SCANFIT_DEFAULTS = dict(
    sf_size=76,           # which of ScanFit's bars: 76, 83 or 88 (ScanFit's palm widths, mm)
    sf_zone_band=18.0,    # the pad follows skin that lies less than this above the lowest skin, mm (ScanFit's cradle: 95 % of what it supports)
    sf_overhang=51.0,     # the underside of the keel is nowhere flatter than this, degrees from the horizontal (the bar's own underside shows
                          # a little past where the keel begins, so this is set 6 degrees over the 45 that is wanted of the print)
    sf_ear_x=54.0,        # the strap ears and slots are centred here, mm from the wrist (ScanFit's two strap slots: 53.5 and 54.9 in this frame)
    sf_slot_flat=17.0,    # flat of the strap slot's roof, mm: here the ear on the thumb side crosses the slot at an angle, so a 19 mm flat
                          # bridged 20.9 mm along the ear (SPEC section 21); 17 mm keeps it under R12's 20 mm
    sf_ear_h=17.0,        # strap ears 1 mm taller than the set's 16 mm, so that 1.8 mm stays over the slot's roof as before
    sf_web=10.0,          # least width of the web that carries the keel on the pad, mm
    sf_web_h=8.5,         # below this height over the pad's base the keel is a web with upright sides, mm
    sf_fall=45.0,         # near the bar the pad's edges fall away at this angle instead of dropping upright, degrees (ScanFit's cradle: 45; less than
                          # sf_overhang, so that a pad edge that runs in under the bar meets the keel once and stays in it)
    sf_slit=1.0,          # where the pad would come closer than this to the keel from below, the room between them is filled, mm
    sf_fillet=2.0,        # ball that fillets pad, web and bar into each other, mm
    sf_blend=3.0,         # the fillet fades out over this distance round the bar, mm
    sf_fit=0.0,           # fitted variant: the bar may rise toward the skin by this much, mm (0: ScanFit's bar as it is)
    sf_fit_reach=3.0,     # the rise fades out where the skin is this much further away than sf_fit, mm
    sf_fit_sigma=1.5,     # the rise is smoothed with a Gaussian of this size, mm
    sf_hard_gap=0.1,      # nothing of the pad is closer than this to the skin as scanned, mm
)


class Sub:
    """A regular grid of nodes, as build.Grid has it, given directly."""
    def __init__(self, x0, y0, p, nx, ny):
        self.x0, self.y0, self.p, self.nx, self.ny = x0, y0, p, nx, ny
        self.X, self.Y = np.meshgrid(x0 + p * np.arange(nx), y0 + p * np.arange(ny), indexing='ij')


def pose_matrix():
    """4 x 4 matrix that puts a hand in the v4 device frame where ScanFit's P1H cradle has it."""
    return np.array(DATA['hand_pose_in_device_frame']['matrix'], float)


def _load(name):
    m = trimesh.load(os.path.join(HERE, 'scanfit', name), process=True)
    m.merge_vertices(digits_vertex=4)
    m.apply_transform(np.array(DATA['scanfit_frame_in_device_frame']['matrix'], float))
    return m


def loft_mesh(size):
    """ScanFit's loft of this size as Fusion leaves it, in the v4 device frame."""
    return _load(DATA['handles']['sizes'][str(int(size))]['file'])


def bar_mesh(size):
    """The bar that is built: the loft with its end edges rounded (tools/scanfit_bars.py), in the v4 device frame."""
    return _load(BARS[str(int(size))]['file'])


def bar_plan(size, grid):
    """Nodes of the grid that lie under the bar."""
    ht, _ = mesh_envelopes(bar_mesh(size), grid)
    return np.isfinite(ht)


def mesh_envelopes(mesh, grid):
    """Highest and lowest point of a closed mesh over every grid node (-inf / +inf where the mesh is not over the node).
    Every triangle is rasterised on the nodes inside its plan outline; heights by barycentric interpolation."""
    top = np.full((grid.nx, grid.ny), -np.inf)
    bot = np.full((grid.nx, grid.ny), np.inf)
    p = grid.p
    for a, b, c in mesh.triangles:
        lo, hi = np.minimum(np.minimum(a, b), c), np.maximum(np.maximum(a, b), c)
        i0, i1 = int(np.ceil((lo[0] - grid.x0) / p)), int(np.floor((hi[0] - grid.x0) / p))
        j0, j1 = int(np.ceil((lo[1] - grid.y0) / p)), int(np.floor((hi[1] - grid.y0) / p))
        if i1 < i0 or j1 < j0:
            continue
        i0, j0, i1, j1 = max(i0, 0), max(j0, 0), min(i1, grid.nx - 1), min(j1, grid.ny - 1)
        if i1 < i0 or j1 < j0:
            continue
        X, Y = grid.X[i0:i1 + 1, j0:j1 + 1], grid.Y[i0:i1 + 1, j0:j1 + 1]
        den = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1])
        if abs(den) < 1e-12:
            continue
        w0 = ((b[1] - c[1]) * (X - c[0]) + (c[0] - b[0]) * (Y - c[1])) / den
        w1 = ((c[1] - a[1]) * (X - c[0]) + (a[0] - c[0]) * (Y - c[1])) / den
        w2 = 1.0 - w0 - w1
        ins = (w0 >= -1e-9) & (w1 >= -1e-9) & (w2 >= -1e-9)
        if not ins.any():
            continue
        z = w0 * a[2] + w1 * b[2] + w2 * c[2]
        t, q = top[i0:i1 + 1, j0:j1 + 1], bot[i0:i1 + 1, j0:j1 + 1]
        t[ins] = np.maximum(t[ins], z[ins])
        q[ins] = np.minimum(q[ins], z[ins])
    return top, bot


def keel(ht, hb, inside, p, deg):
    """Underside of the least body that contains the bar and has no overhang flatter than `deg` (see the module text). ht, hb: highest
    and lowest point of the bar over the nodes, p: pitch of the nodes. Returns the height of that underside over the nodes under the bar;
    it equals hb where the bar's own underside is steep enough.
    The distance r to the outline of a section comes from a Euclidean distance transform, which knows it to within one pitch (the outline
    runs somewhere between the last node inside and the first node outside). Within 2.5 pitches of the outline it is refined inside that
    bracket to (z' - hb) / |grad hb|, the first-order distance to the line where the bar's underside reaches z'. With it the result is hb
    itself wherever the underside is steeper than `deg`, not hb less a fraction of a pitch."""
    t = np.tan(np.radians(deg))
    out = np.where(inside, hb, np.inf)
    mid = 0.5 * (np.where(inside, ht, 0.0) + np.where(inside, hb, 0.0))
    gx, gy = np.gradient(np.where(inside, hb, np.nan), p)
    g = np.hypot(gx, gy)                                               # not a number at the outline of the plan and outside it
    ok = np.isfinite(g) & (g > 1e-6)
    for z in np.arange(float(hb[inside].min()) + p, float(mid[inside].max()) + p, p):
        lay = inside & (hb <= z) & (ht >= z)
        if not lay.any():
            continue
        r = ndimage.distance_transform_edt(lay) * p                     # to the nearest node outside the section
        lin = np.where(ok & lay, (z - np.where(lay, hb, 0.0)) / np.where(ok, g, 1.0), np.inf)
        r = np.where(r <= 2.5 * p, np.clip(lin, np.maximum(r - p, 0.0), r), r - 0.5 * p)
        out = np.where(lay, np.minimum(out, z - t * np.maximum(r, 0.0)), out)
    return np.where(inside, np.minimum(out, np.where(inside, hb, 0.0)), np.inf), np.where(ok, g, np.inf)


def plan_axes(inside, grid):
    """Centre of the bar's plan outline and its two directions in plan: along the bar (toward +Y) and across it (toward +X, the fingertips)."""
    P = np.c_[grid.X[inside], grid.Y[inside]]
    c = P.mean(0)
    w, E = np.linalg.eigh(np.cov((P - c).T))
    a = E[:, -1] if E[1, -1] > 0 else -E[:, -1]
    e = np.array([a[1], -a[0]])
    return c, a, (e if e[0] > 0 else -e)


def fall_away(f, p, deg, rad):
    """The surface f with every drop steeper than `deg` replaced by a slope of `deg`: highest of f(q) - tan(deg) * |p - q| over q within rad."""
    n = int(np.ceil(rad / p))
    a = np.arange(-n, n + 1) * p
    dd = np.hypot(a[:, None], a[None, :])
    return ndimage.grey_dilation(f, footprint=dd <= rad + 1e-9, structure=-np.tan(np.radians(deg)) * dd, mode='nearest')


def land_limit(dev, grid, env, floor, go, pad_gap, where):
    """The limit of the fitted grip (grip.py, step 4) over the nodes `where`: highest surface that keeps grip_gap off the smoothed skin and
    pad_gap under the skin as scanned, with grip_slack of room sideways and then a fall-away at grip_slope. Returns the limit and the
    signed distance field of the scan."""
    p = grid.p
    lo = np.array([grid.x0, grid.y0, floor - 2 * p])
    hi = np.array([grid.x0 + p * (grid.nx - 1), grid.y0 + p * (grid.ny - 1), float(dev.bounds[1][2]) + 4.0])
    F, _ = SDF.build(dev, pitch=p, lo=lo, hi=hi, band=2.0)
    Fs = SDF.Field(F.lo, F.h, ndimage.gaussian_filter(F.v, go['grip_sigma'] / p, mode='nearest'))
    envs, _ = GR.offset_skin(Fs, go['grip_gap'])
    envs = np.minimum(envs, np.where(np.isfinite(env), env - pad_gap, np.inf))
    box = np.where(where)
    span = float(np.nanmax(np.where(np.isfinite(envs), envs, np.nan)[box])) - floor if np.isfinite(envs[box]).any() else 30.0
    rad = min(30.0, span / np.tan(np.radians(go['grip_slope'])) + go['grip_slack'] + 2 * p)
    n = int(np.ceil(rad / p))
    i0, i1 = box[0].min(), box[0].max() + 1
    j0, j1 = box[1].min(), box[1].max() + 1
    aa = np.arange(-n, n + 1) * p
    dd = np.hypot(aa[:, None], aa[None, :])
    cone = -np.tan(np.radians(go['grip_slope'])) * np.maximum(dd - go['grip_slack'], 0.0)
    big = np.pad(np.where(np.isfinite(envs), envs, 1e3), n, mode='constant', constant_values=1e3)
    lim = ndimage.grey_erosion(big[i0:i1 + 2 * n, j0:j1 + 2 * n], footprint=dd <= rad + 1e-9, structure=cone, mode='constant', cval=1e3)[n:-n, n:-n]
    out = envs.copy()
    out[i0:i1, j0:j1] = np.where(lim > 500, np.inf, lim)
    return out, F


def _runs(flag, close, open_):
    """A row of yes/no along the bar with gaps shorter than `close` closed and runs shorter than `open_` dropped."""
    f = ndimage.binary_closing(np.pad(flag, close, mode='edge'), structure=np.ones(close))[close:-close] if close > 1 else flag
    return ndimage.binary_opening(np.pad(f, open_, mode='edge'), structure=np.ones(open_))[open_:-open_] if open_ > 1 else f


def scanfit_grip(dev, grid, top0, outline, floor, o, env, pad_gap=0.2, go=None, base_t=0.8, to_manifold=None):
    """dev: hand mesh in the device frame, already in ScanFit's posture. top0: pad top without a bar. env: lowest skin as scanned over each
    node. Returns the node heights of the height-field part of the pad, the solids to be joined to it (bar, keel, web, web foot and, in the fitted variant, the
    rise; each a dictionary with name and either vertices v, faces f and optionally a plan outline `clip` to cut it to, or `slabs`, a list of
    (plan outline, z0, z1) plates), and a dictionary for the report."""
    p = grid.p
    go = dict(GR.GRIP_DEFAULTS, **(go or {}))
    t_over = np.tan(np.radians(o['sf_overhang']))
    bar = bar_mesh(o['sf_size'])
    ht, hb = mesh_envelopes(bar, grid)
    inside = np.isfinite(ht) & np.isfinite(hb)
    mid = np.where(inside, 0.5 * (ht + hb), 0.0)
    size = str(int(o['sf_size']))
    info = dict(options={k: o[k] for k in SCANFIT_DEFAULTS}, source=DATA['about'],
                bar=dict(loft=DATA['handles']['sizes'][size], rounded=BARS.get(size), bounds_device_frame_mm=np.round(bar.bounds, 2).tolist(),
                         plan_area_mm2=round(float(inside.sum() * p * p), 1), top_z_max=round(float(ht[inside].max()), 2), lowest_z=round(float(hb[inside].min()), 2)))
    # --- the keel, on a grid four times finer -----------------------------------------------------------------------------------------
    ii, jj = np.where(inside)
    i0, i1, j0, j1 = max(ii.min() - 4, 0), min(ii.max() + 4, grid.nx - 1), max(jj.min() - 4, 0), min(jj.max() + 4, grid.ny - 1)
    q = 4
    fine = Sub(grid.x0 + i0 * p, grid.y0 + j0 * p, p / q, (i1 - i0) * q + 1, (j1 - j0) * q + 1)
    htf, hbf = mesh_envelopes(bar, fine)
    insf = np.isfinite(htf) & np.isfinite(hbf)
    kf, gf = keel(htf, hbf, insf, fine.p, o['sf_overhang'])
    df = np.where(insf, hbf - kf, 0.0)                                   # thickness of the keel under the bar's own underside
    wsm = np.clip((df - 0.1) / 0.2, 0.0, 1.0)                            # smoothed (0.3 mm) where the keel is thicker than 0.3 mm; its thin edge keeps its own values
    df = np.where(insf & (gf < 1.02 * t_over), wsm * ndimage.gaussian_filter(df, 0.3 / fine.p) + (1 - wsm) * df, 0.0)   # none where the bar's own underside is steep enough
    d = np.zeros(top0.shape)
    d[i0:i1 + 1, j0:j1 + 1] = df[::q, ::q]
    d = np.where(inside, d, 0.0)
    bC = np.where(inside, hb - d, np.inf)                                # underside of the keel over the pad's nodes
    # --- along and across the bar ------------------------------------------------------------------------------------------------------
    c, a, e = plan_axes(inside, grid)
    s = (grid.X - c[0]) * a[0] + (grid.Y - c[1]) * a[1]
    u = (grid.X - c[0]) * e[0] + (grid.Y - c[1]) * e[1]
    s0 = float(s[inside].min())
    k = np.clip(np.round((s - s0) / 0.5).astype(int), 0, None)
    n = int(k[inside].max()) + 1
    k = np.clip(k, 0, n - 1)
    uA, zA = np.full(n, np.nan), np.full(n, np.nan)
    for b in range(n):
        m = inside & (k == b)
        if m.sum() >= 3:
            w = int(np.argmin(bC[m]))
            uA[b], zA[b] = u[m][w], bC[m][w]
    ok = np.isfinite(uA)
    xs = np.arange(n)
    uA, zA = np.interp(xs, xs[ok], uA[ok]), np.interp(xs, xs[ok], zA[ok])
    uA, zA = ndimage.gaussian_filter1d(uA, 4.0, mode='nearest'), ndimage.gaussian_filter1d(zA, 4.0, mode='nearest')     # 2 mm along the bar
    base = floor + base_t
    hw = np.maximum(o['sf_web'] / 2, (base + o['sf_web_h'] - zA) / t_over)                                                # half width of the web
    # The web. The keel's underside has valleys: the line under the middle of the bar, and, because the bar's ends are cut at an angle to
    # its length, side valleys that run out to the end corners. A valley that stands on nothing would start in mid-air, so the web stands
    # under every one of them: all nodes within sf_web / 2 of a valley, and all nodes where the keel is lower than sf_web_h over the base.
    # It keeps 1 mm inside the bar's plan outline. Its sides are smooth and upright: the node set is turned into an outline in plan (cell
    # squares joined, notches under 2 mm closed, corners rounded to 1 mm) and cut out of the block under the bar's top, as a solid of
    # its own; as part of the height field its sides would show the grid's 0.5 mm steps wherever they run askew to it.
    import shapely
    from shapely.geometry import box as sbox
    from shapely.ops import unary_union
    gxf, gyf = np.gradient(np.where(insf, hbf - df, np.nan), fine.p)
    slf = np.hypot(gxf, gyf)
    valley_f = insf & np.isfinite(slf) & (slf < 0.6 * t_over)       # both walls of a valley rise at tan(sf_overhang) or more; on its line, and at a lowest point, the slope drops
    kff = np.where(insf, hbf - df, np.inf)                               # a lowest point near the bar's outline has no slope to read: found as the least value within 1.5 mm
    rr = int(round(1.5 / fine.p)); aa_ = np.arange(-rr, rr + 1)
    valley_f |= insf & (kff <= ndimage.minimum_filter(kff, footprint=np.hypot(aa_[:, None], aa_[None, :]) <= rr, mode='nearest') + 0.05)
    valley = np.zeros(top0.shape, bool)
    valley[i0:i1 + 1, j0:j1 + 1] = ndimage.maximum_filter(valley_f, size=q)[::q, ::q]
    core = inside & ((ndimage.distance_transform_edt(~valley) * p <= o['sf_web'] / 2) | (bC <= base + o['sf_web_h']))
    # where the underside as the pad's grid can carry it would still be flatter than 47 degrees (the keel's thin edge under a tightly curved
    # part of the bar is narrower than a grid cell), the web is widened to stand under it
    und = np.where(inside, np.where(d > 0.01, hb - d, hb), np.nan)
    gxc, gyc = np.gradient(und, p)
    slc = np.hypot(gxc, gyc)
    weak = inside & np.isfinite(slc) & (slc < np.tan(np.radians(47.0)))
    core |= ndimage.binary_dilation(weak, iterations=2) & inside
    core &= ndimage.distance_transform_edt(inside) * p >= 1.0
    wi, wj = np.where(core)
    strip = unary_union([sbox(grid.x0 + i_ * p - p / 2, grid.y0 + j_ * p - p / 2, grid.x0 + i_ * p + p / 2, grid.y0 + j_ * p + p / 2) for i_, j_ in zip(wi, wj)])
    strip = strip.buffer(1.0, quad_segs=8).buffer(-2.0, quad_segs=8).buffer(1.0, quad_segs=8)
    web = inside & shapely.contains_xy(strip, grid.X, grid.Y)
    rear = inside & (u < uA[k] - hw[k])
    # --- the palm pad behind the bar -----------------------------------------------------------------------------------------------------
    near = ndimage.distance_transform_edt(~inside) * p
    span = float(np.max(top0[near <= 12.0]) - base)
    E = fall_away(top0, p, o['sf_fall'], min(30.0, span / np.tan(np.radians(o['sf_fall'])) + 2 * p))
    T0 = np.where((near <= 12.0) & (top0 <= base + 1e-6), np.maximum(top0, E), top0)        # only where the pad is at its base level: the raised pad under the hand is not touched
    filled = inside & (T0 >= bC - 0.3)                                   # columns that are solid from the pad to the bar anyway
    lim, F = land_limit(dev, grid, env, floor, go, pad_gap, near <= 10.0)
    for _ in range(3):
        T1 = np.where(filled, np.maximum(T0, ht - 0.05), T0)
        wgt = np.clip(1.0 - (near - o['sf_fillet']) / o['sf_blend'], 0.0, 1.0)
        wgt = wgt * wgt * (3 - 2 * wgt)
        T2 = wgt * GR.roll_over(T1, o['sf_fillet'], p) + (1 - wgt) * T1
        tight = inside & ~filled & ~web & (T2 > bC - o['sf_slit'])       # the pad would come closer than sf_slit to the keel from below: fill instead of leaving a slit
        if not tight.any():
            break
        filled = filled | tight
    top, n_cut, deepest = GR.keep_clear(T2, F, grid, (T2 > top0 + 1e-6), o['sf_hard_gap'], go['grip_dimple'], floor_top=top0)
    # --- solids -----------------------------------------------------------------------------------------------------------------------------
    tau = 0.01
    topF = np.where(inside, np.minimum(hb + 1.0, mid), 0.0)              # inside the bar
    botF = np.where(inside, np.where(d > tau, hb - d, hb + 0.03), 0.0)   # 0.03 mm inside the bar where there is no keel, so that no two faces coincide
    ndF = inside & ndimage.binary_dilation(d > tau, iterations=2) & (topF - botF > 0.03)
    solids = [dict(name='bar', v=bar.vertices, f=bar.faces)]
    cellsF = grid.cells(ndF)
    if cellsF.any():
        v, f = prism(grid.x0, grid.y0, p, topF, 0.0, cellsF, bottom=botF)
        solids.append(dict(name='keel', v=v, f=f))
    v, f = prism(grid.x0, grid.y0, p, np.where(inside, ht - 0.05, 0.0), floor, grid.cells(inside))
    solids.append(dict(name='web', v=v, f=f, clip=strip))               # the block under the bar's top, cut to the strip
    # the web's foot: a fillet of radius sf_fillet on the pad's base, as a stack of thin plates (0.1 mm, half a print layer) whose outline is
    # the strip grown by what a quarter circle asks for at that height
    rf, dz = o['sf_fillet'], 0.1
    plates = []
    for j in range(int(round(rf / dz))):
        zt = (j + 1) * dz
        grow = rf - np.sqrt(max(rf * rf - (rf - zt) ** 2, 0.0))
        if grow > 0.02:
            plates.append((strip.buffer(grow, quad_segs=16), base - 0.3 if j == 0 else base + j * dz - 0.02, base + zt))
    solids.append(dict(name='web foot', slabs=plates))
    # --- fitted variant: the bar raised toward the skin where the skin is within reach ----------------------------------------------------
    rise = np.zeros(top0.shape)
    over = inside & np.isfinite(lim)
    room = (lim - ht)[over]
    info['room_between_bar_and_landing_limit_mm'] = dict(min=round(float(room.min()), 2), p05=round(float(np.quantile(room, 0.05)), 2), median=round(float(np.median(room)), 2),
                                                         share_of_bar_plan_under_the_hand=round(float(over.sum() / inside.sum()), 3),
                                                         share_where_the_bar_is_above_the_limit=round(float((room < 0).mean()), 4))
    if o['sf_fit'] > 0:
        g = np.where(over, lim - ht, np.inf)
        wg = np.clip((o['sf_fit'] + o['sf_fit_reach'] - g) / o['sf_fit_reach'], 0.0, 1.0)
        wg = wg * wg * (3 - 2 * wg)
        rise = np.where(over, np.clip(g, 0.0, o['sf_fit']) * wg, 0.0)
        rise = np.where(inside, ndimage.gaussian_filter(rise, o['sf_fit_sigma'] / p), 0.0)
        capf = np.where(inside, np.minimum(ht + rise, np.maximum(lim, ht)), floor)              # never above the limit, never below ScanFit's bar
        soft = np.clip(rise / 0.2, 0.0, 1.0)
        cap = soft * GR.roll_under(capf, go['grip_ball'], p) + (1 - soft) * capf
        cap = np.where(inside, np.maximum(cap, ht), floor)
        capk, _, _ = GR.keep_clear(cap, F, grid, inside & (cap > ht + 0.02), o['sf_hard_gap'], go['grip_dimple'], floor_top=np.where(inside, ht, floor))
        rise = np.where(inside, np.maximum(capk - ht, 0.0), 0.0)
        ndR = inside & ndimage.binary_dilation(rise > 0.02, iterations=1) & (ht - hb > 1.0)
        cellsR = grid.cells(ndR)
        if cellsR.any():
            v, f = prism(grid.x0, grid.y0, p, np.where(inside, ht + rise, 0.0), 0.0, cellsR, bottom=np.where(inside, ht - 0.3, 0.0))
            solids.append(dict(name='rise', v=v, f=f))
        info['fit'] = dict(nodes_raised=int((rise > 0.05).sum()), plan_area_raised_mm2=round(float((rise > 0.05).sum() * p * p), 1), largest_rise_mm=round(float(rise.max()), 2),
                           volume_added_cm3=round(float(rise.sum() * p * p / 1000), 3))
    # --- what of the bar is open to the hand -------------------------------------------------------------------------------------------------
    P, fi = trimesh.sample.sample_surface(bar, 80000, seed=7)
    N = bar.face_normals[fi]
    gi, gj = (P[:, 0] - grid.x0) / p, (P[:, 1] - grid.y0) / p
    samp = lambda A: ndimage.map_coordinates(A, [gi, gj], order=1, mode='nearest')
    in_hf = P[:, 2] < samp(top) - 0.03                                   # under the height-field part of the pad
    kb = samp(np.where(inside, botF, 1e3)); kt = samp(np.where(inside, topF, -1e3)); dk = samp(d)
    in_keel = (dk > tau + 0.1) & (P[:, 2] > kb + 0.02) & (P[:, 2] < kt)
    in_rise = (samp(rise) > 0.05) & (P[:, 2] > samp(np.where(inside, ht, 0.0)) - 0.25)
    in_web = shapely.contains_xy(strip, P[:, 0], P[:, 1]) & (N[:, 2] < 0)
    open_ = ~(in_hf | in_keel | in_rise | in_web)
    sP = (P[:, 0] - c[0]) * a[0] + (P[:, 1] - c[1]) * a[1]
    uP = (P[:, 0] - c[0]) * e[0] + (P[:, 1] - c[1]) * e[1]
    kP = np.clip(np.round((sP - s0) / 0.5).astype(int), 0, n - 1)
    # angle round the bar: 0 at the top, +90 at the widest line toward the fingertips, -90 toward the palm; from the surface normal
    ang = np.degrees(np.arctan2(N[:, 0] * e[0] + N[:, 1] * e[1], N[:, 2]))
    rows = []
    for x in np.arange(np.ceil((s0 + 6) / 10) * 10, sP.max() - 5.9, 10.0):
        m = np.abs(sP - x) < 5.0
        def reach(side):
            last = 0.0
            for b in np.arange(0.0, 180.0, 5.0):
                mm = m & (np.sign(ang) == side) & (np.abs(ang) >= b) & (np.abs(ang) < b + 5)
                if mm.sum() < 10 or open_[mm].mean() < 0.5:
                    break
                last = b + 5
            return last - 90.0
        rows.append(dict(station_mm=float(x), open_share=round(float(open_[m].mean()), 3), fingertip_side_open_to_deg_below_widest_line=reach(1.0), palm_side_open_to_deg_below_widest_line=reach(-1.0)))
    clear = F.at(P[open_])
    info.update(built=True, frame=dict(centre_plan=np.round(c, 2).tolist(), along=np.round(a, 4).tolist(), across_toward_fingertips=np.round(e, 4).tolist()),
                keel=dict(overhang_deg=o['sf_overhang'], plan_area_mm2=round(float((d > tau).sum() * p * p), 1), thickest_mm=round(float(d.max()), 2),
                          volume_cm3=round(float(np.maximum(d - tau, 0.0).sum() * p * p / 1000), 3),
                          lowest_edge_over_pad_base_mm=round(float(zA.min() - base), 2)),
                web=dict(least_width_mm=o['sf_web'], plan_area_mm2=round(float(strip.area), 1), pieces=len(getattr(strip, 'geoms', [strip])),
                         valley_nodes=int(valley.sum()), nodes_flatter_than_47deg_stood_under=int((weak & ~valley).sum()), inside_the_bar_plan_outline_by_mm=1.0),
                behind_the_bar=dict(stations_where_the_pad_runs_into_the_bar_mm=[[round(float(s0 + 0.5 * r0), 1), round(float(s0 + 0.5 * r1), 1)] for r0, r1 in _spans(_runs(_share(filled & rear, rear, k, n) > 0.5, 4, 4))],
                                    filled_plan_area_mm2=round(float((filled & ~web).sum() * p * p), 1)),
                bar_surface=dict(area_mm2=round(float(bar.area), 1), open_to_the_hand_share=round(float(open_.mean()), 4), by_station=rows,
                                 note='Open: not covered by pad, keel, web or fitted rise. Angle from the surface normal: 0 at the top, 90 at the widest line. '
                                      'Stations along the bar from the centre of its plan outline, negative toward the thumb.'),
                bar_to_skin_as_scanned_mm=dict(nearest=round(float(clear.min()), 2), p05=round(float(np.quantile(clear, 0.05)), 2), median=round(float(np.median(clear)), 2),
                                               share_within_1mm=round(float((clear <= 1).mean()), 4), share_within_2mm=round(float((clear <= 2).mean()), 4),
                                               share_within_5mm=round(float((clear <= 5).mean()), 4)),
                nodes_that_needed_lowering_for_the_skin_as_scanned=n_cut, deepest_lowering_mm=round(deepest, 3),
                top_z_max=round(float(max(ht[inside].max(), (ht + rise)[inside].max())), 2), height_over_pad_floor_mm=round(float((ht + rise)[inside].max() - floor), 2),
                nodes_changed=int((np.abs(top - top0) > 1e-6).sum()),
                volume_added_cm3=round(float(np.maximum(top - top0, 0.0).sum() * p * p / 1000), 2))
    view = np.where(inside, np.maximum(top, ht + rise), top)             # the pad as seen from above
    aux = dict(field=F, foot=inside, top0=top0, ht=ht, hb=hb, lim=lim, keel=bC, filled=filled, web=web, view=view, rise=rise)
    return top, solids, dict(info, _aux=aux)


def _share(part, whole, k, n):
    """Per station along the bar: share of the nodes `whole` that are in `part`."""
    a_, b_ = np.zeros(n), np.zeros(n)
    np.add.at(a_, k[part], 1.0)
    np.add.at(b_, k[whole], 1.0)
    return np.where(b_ > 0, a_ / np.maximum(b_, 1.0), 0.0)


def _spans(flag):
    out, start = [], None
    for i, v in enumerate(flag):
        if v and start is None:
            start = i
        if not v and start is not None:
            out.append((start, i - 1)); start = None
    if start is not None:
        out.append((start, len(flag) - 1))
    return out
