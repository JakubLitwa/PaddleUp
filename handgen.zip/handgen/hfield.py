"""Height-field solids: a closed prism between a flat floor and a surface given on a regular grid.

Nodes sit at (x0 + i*pitch, y0 + j*pitch). A cell (i, j) uses nodes (i, j), (i+1, j), (i, j+1), (i+1, j+1) and is
part of the solid when `cells[i, j]` is true. The result is a closed, consistently wound triangle mesh."""
import numpy as np


def clean_cells(cells):
    """Remove single-cell necks so that no vertex is shared by two cells that touch only at a corner."""
    c = cells.copy()
    while True:
        a, b, d, e = c[:-1, :-1], c[1:, :-1], c[:-1, 1:], c[1:, 1:]
        p1 = a & e & ~b & ~d
        p2 = b & d & ~a & ~e
        if not (p1.any() or p2.any()):
            return c
        c[:-1, :-1][p1] = False
        c[1:, :-1][p2] = False


def largest_component(cells):
    from scipy import ndimage
    lab, n = ndimage.label(cells)
    if n <= 1:
        return cells
    sizes = ndimage.sum(cells, lab, range(1, n + 1))
    return lab == (1 + int(np.argmax(sizes)))


def prism(x0, y0, pitch, top, floor, cells, bottom=None):
    """top: node heights, shape (nx, ny). cells: bool, shape (nx-1, ny-1). floor: z of the flat bottom,
    or `bottom` = node heights of a second surface. Returns (vertices, faces)."""
    nx, ny = top.shape
    cells = clean_cells(cells)
    idx = np.arange(nx * ny).reshape(nx, ny)
    I, J = np.nonzero(cells)
    a, b, c, d = idx[I, J], idx[I + 1, J], idx[I + 1, J + 1], idx[I, J + 1]
    N = nx * ny
    tris = [np.stack([a, b, c], 1), np.stack([a, c, d], 1),              # top, normal +z
            np.stack([a + N, c + N, b + N], 1), np.stack([a + N, d + N, c + N], 1)]   # bottom, normal -z
    pad = np.zeros((nx + 1, ny + 1), bool)
    pad[1:-1, 1:-1] = cells

    def wall(mask_nb, p, q):
        # p -> q is the cell edge walked so that the outside is on the right of the solid's outward normal
        K = cells & ~mask_nb
        i, j = np.nonzero(K)
        u, v = idx[i + p[0], j + p[1]], idx[i + q[0], j + q[1]]
        tris.append(np.stack([u, u + N, v + N], 1))
        tris.append(np.stack([u, v + N, v], 1))
    wall(pad[:-2, 1:-1], (0, 1), (0, 0))     # -x side
    wall(pad[2:, 1:-1], (1, 0), (1, 1))      # +x side
    wall(pad[1:-1, :-2], (0, 0), (1, 0))     # -y side
    wall(pad[1:-1, 2:], (1, 1), (0, 1))      # +y side
    F = np.concatenate(tris)
    X, Y = np.meshgrid(x0 + pitch * np.arange(nx), y0 + pitch * np.arange(ny), indexing='ij')
    zt = np.where(np.isfinite(top), top, 0.0)
    zb = np.full_like(zt, floor) if bottom is None else np.where(np.isfinite(bottom), bottom, 0.0)
    V = np.concatenate([np.stack([X, Y, zt], -1).reshape(-1, 3), np.stack([X, Y, zb], -1).reshape(-1, 3)])
    used = np.unique(F)
    remap = np.full(len(V), -1)
    remap[used] = np.arange(len(used))
    return V[used], remap[F]
