"""PaddleUp v4 hand generator: builds the hand tray (PETG) and pad (TPU) from a hand scan."""
__version__ = '4.3.0'
