# handgen: the PaddleUp v4 hand generator

Builds the hand module of PaddleUp v4 from a 3D scan of the wearer's hand: a PETG tray, a TPU pad whose top follows the scanned skin, and a flat TPU pad for the hand strap. Since release 4.2 the pad's grip bar can be shaped by the scan as well (`--grip fitted`); since 4.3 the module can be built with the posture and the bar of the ScanFit design (`--grip scanfit`). It also reports what it measured and how well the pad fits.

The scan is read from disk and nothing is sent anywhere. The package holds no scan and no scan-derived data; `interface/` holds only the three solids exported once from the Fusion arm model, and `scanfit/` the bars of the ScanFit design with two rigid placements.

## One command

Run from `paddleup/v4` (Python 3.11 or later; `pip install trimesh manifold3d scipy numpy shapely rtree networkx matplotlib`):

```
python -m handgen build --scan ../scan/PickleballHand_clean.stl --frame ../data/hand_device_frame.json --out hand
```

Without `--frame` the device frame is taken from the flat cap that the scanning software puts over the open wrist end. `--hand R` builds for a right hand. `--pitch-offset` and `--yaw-offset` (degrees) rebuild the tray and pad for another wrist posture.

Output in `hand/`: `pad.stl`, `tray.stl`, `strap_pad.stl` (device frame), `print/PaddleUp_v4_*_{TPU,PETG}.stl` (print orientation, lowest point at z = 0), `report.json`, `report.md`, `gap_map.png`, `grid.npz`. Two runs give identical files.

Since release 4.1.0 the plan outlines of tray and pad are smooth curves (the half level of the blurred grid mask; rim and ear tops rounded) instead of the grid's 0.5 mm stair-steps; the pad's top surface is the same height field as before. `--stepped` builds the outlines of release 4.0.0.

## Fitted grip (release 4.2)

`build --grip fitted` replaces the pad's round bar by a bar that the scanned hand has shaped. The tray and the strap pad come out as without the option, and the pad sits in the same tray.

```
python -m handgen build --scan ../scan/PickleballHand_clean.stl --frame ../data/hand_device_frame.json --out hand_fitted --grip fitted
```

How it is shaped (`grip.py`; the steps and their sources are in its header):

1. The skin is smoothed (Gaussian, 1.2 mm) so that creases and scan noise do not end up in the grip.
2. Along the curl axis, the largest ball that fits between the smoothed skin and the pad is found every millimetre. The grip runs as far as skin lies within 5 mm of that ball on the finger side and on the heel side.
3. A barrel through those balls, 1.15 times as thick, with a flattened dome at each end.
4. Wherever the smoothed skin, less 0.3 mm, is lower than the barrel, the barrel is cut down to it. Beside steep skin it keeps 0.75 mm of room sideways and then falls away at 55°, as the rest of the pad does, so a hand that lands a little off is not held up by it.
5. A 4 mm ball rolled over the surface fillets the grip into the pad; then a 6 mm ball is rolled under it, so the rolled surface has no outward curve tighter than that. (Measured on the finished pad for the brief's scan: 99.7 % of the grip's outward curves have a radius of 4 mm or more; `data/grip_checks.txt`.)
6. The result is checked against the skin as scanned and, as solids, against the whole scan; where it would come within 0.1 mm it gives way in a shallow dimple.

Options: `--grip-swell`, `--grip-ball`, `--grip-gap`, `--grip-sigma`, `--grip-fillet`, `--grip-cover`, `--grip-slack`, `--grip-slope`. If the hand leaves no hollow at least 20 mm long (a flat hand), the pad keeps its round bar and the report says so.

The report gains a section "Fitted grip against the round bar, on this scan": the area of scanned skin that faces the pad and lies within 0.5, 1 and 2 mm of it, for both pads. `tools/grip_sweep.py` repeats that for several settings and adds how a hand rests that is set down a little off its scanned place, `tools/grip_checks.py` checks mesh, seat, curvature and slicing, `tools/grip_figure.py` and `tools/render_three/pads.py` draw the figures.

Without `--grip fitted` the generator writes the files of release 4.1 byte for byte (checked on the brief's scan on 11 Nov 2026).

## ScanFit ergonomics (release 4.3)

`build --grip scanfit` builds the hand module with the ergonomics of the user's Fusion design PaddleUp_ScanFit: the hand turned 20° toward the back of the hand at the wrist, closing round ScanFit's P1H bar at the place that bar has in ScanFit. Pad, tray and strap pad all differ from the default build; they go together.

```
python -m handgen build --scan ../scan/PickleballHand_clean.stl --frame ../data/hand_device_frame.json --out hand_scanfit --grip scanfit
```

What it does (`scanfit.py`; rules H1 to H11 in `../SPEC.md` §17):

1. The scan is moved by ScanFit's rigid move (`scanfit/scanfit.json`) before anything else. `--pose scanfit` does only this, with any grip; `--pose FILE` takes any other 4 × 4 matrix.
2. The pad follows the skin up to 18 mm above the lowest skin (`--zone-band`), which is where ScanFit's cradle carries the hand.
3. The bar is `scanfit/p1h_bar_76.stl`: ScanFit's loft with its two end edges rounded by a 3 mm ball (`../tools/scanfit_bars.py`, figures in `scanfit/bars.json`). It is joined to the pad as a solid, not as part of the height field, so its underside stays open.
4. Under the bar stands a keel, the least body whose underside is nowhere flatter than 51°, on a web under each of its valleys. Near the bar the pad's edges fall away at 45° and join the keel where they meet it.
5. Pad and tray reach round the bar; the strap ears sit 54 mm from the wrist.

The report gains `scanfit_grip`: the bar, keel and web, how much of the bar is open to the hand by station, and the nearest skin. `../tools/scanfit_checks.py` compares the build with ScanFit's own handle and cradle when their exports are given (they are not kept in the repository) and slices it.

What is in `scanfit/`: three lofts (`p1h_handle_*.stl`) and three bars (`p1h_bar_*.stl`) in ScanFit's frame, and two rigid placements. None of it is taken from a scan. Only size 76 was built and checked; `--grip-size 83` and `88` use the other bars at their ScanFit places. `--grip-fit N` lets the bar rise by up to N mm toward the scanned skin; on the brief's scan it gains 14 mm² of skin within 1 mm and no print file was made of it. `generic` does not take a ScanFit build.

## Seat: the hand is raised, not refused

The arm and the paddle parts are the same for every user: the tray's underside is 25 mm below the forearm axis. If the lowest skin of a hand would leave less than 3 mm of TPU, `build` raises the hand along +Z by what is missing (rounded up to 0.01 mm), up to `--max-lift` (6 mm), and shapes the pad for the raised hand. The report gives `seat_drop_needed_as_scanned` and `lift_applied_mm`. Beyond the limit `build` stops with a message; `--no-lift` switches the raise off. `generic` and `evaluate` place the hand as the build did. At 6 mm the line from the middle of the cuff (70 mm behind the wrist) to the wrist is tilted by atan(6 / 70) = 4.9°; the limit is a choice, not a measurement.

## Other modes

| Command | What it does |
|---|---|
| `python -m handgen generic --scan S --frame F --build hand --out hand/generic` | Builds a generic pad from five caliper numbers (recipe in `generic.py`), scores it and the scan-built pad on the same scan, and repeats with the hand shifted by 1, 2, 3 mm and turned by 2° and 5°. The last row lets the hand settle where each pad suits it best (X, Y ±6 mm, yaw ±10°) |
| `python -m handgen evaluate --pad P.stl --scan S2.stl --build hand` | Scores any pad against any scan, for example a second scan of the same hand taken later |
| `python -m handgen arm --scan arm_and_hand.stl --out arm.json` | Reads wrist and forearm sizes from a scan that includes forearm and writes the parameters for the Fusion model |

## How the pad is shaped

1. Lowest skin height over a 0.5 mm grid, seen from below (the palm side).
2. Lowered to the lowest value among the neighbouring nodes, minus a 0.2 mm clearance, so the surface between nodes stays under the skin.
3. Slope-limited to 55°: g(p) = min over q of [f(q) + tan 55° · |p − q|]. Where the skin is steeper, the pad falls away instead of forming a wall beside it.
4. Raised only around the contact zone (skin below Z −5 mm); elsewhere a 0.8 mm soft floor.
5. Grip bar: a ridge with a round top on the axis of the largest cylinder that fits the relaxed curl, 0.4 mm smaller in radius, never more than 18.4 mm across.
6. Flat underside; recesses for the arm's two T-lips.

## Fit numbers

The contact zone is every scan vertex below Z −5 mm inside the tray outline. The gap of a vertex is its distance to the nearest point of the pad surface (surface points at most about 0.18 mm apart). "Resting" in the sweep means the hand is moved straight up or down until it first touches the pad; pad and hand are treated as rigid.

**How far the scan's advantage reaches** (sweep on the brief's scan, `hand/generic/generic_vs_scan.txt`): within about 2 to 3 mm and 2° of the scanned posture the scan-built pad keeps the gap at half the generic pad's or less; at 5° of yaw it does not (the two are alike). The device frame itself is uncertain by about that much (the frame from the wrist cap and the frame file differ by 1.3°), so only a second scan of the same hand, scored with `evaluate`, can show how far a real hand moves between sessions.
