"""Generic pad: the same pad built without a scan, from five numbers a maker can take with calipers (SPEC S4, A6a).

Recipe. The underside of the heel of the hand is taken as a shallow bowl, the rest of the hand is not supported, and the
grip bar sits where a relaxed hand usually curls:
  lowest point of the heel   z_h = -(wrist_thickness / 2) - 0.16 * wrist_thickness, at x_h = 0.24 * hand_length, y = 0
  bowl                       z = z_h + 8 mm * (y / (wrist_width / 2))^2 + 5 mm * ((x - x_h) / x_h)^2, for 1 <= x <= 0.40 * hand_length
  grip bar                   diameter = curl_diameter - 0.8 mm, centre at x = 0.57 * hand_length, y = -0.10 * hand_width,
                             z = z_h + curl_diameter / 2, axis at 65 degrees to the forearm toward the thumb
  outline                    1 <= x <= hand_length + 3, |y| <= hand_width / 2 + 3
The proportions 0.16, 0.24, 0.40, 0.57, 0.10 and the 8 and 5 mm rises were set by eye on the one scan this project has.
A different hand would fit them worse; the comparison with the scan-built pad is therefore favourable to the generic pad."""
import numpy as np
from scipy import ndimage
from .build import Grid, DEFAULTS, IFACE, pad_top, build_pad


def generic_skin(grid, hand_length, hand_width, wrist_width, wrist_thickness):
    X, Y = grid.X, grid.Y
    zh = -(wrist_thickness / 2) - 0.16 * wrist_thickness
    xh = 0.24 * hand_length
    bowl = zh + 8.0 * (Y / (wrist_width / 2)) ** 2 + 5.0 * ((X - xh) / xh) ** 2
    heel = (X >= 0) & (X <= 0.40 * hand_length) & (np.abs(Y) <= wrist_width / 2 + 2.0)
    foot = (X >= 0) & (X <= hand_length) & (np.abs(Y) <= hand_width / 2)
    env = np.where(heel, bowl, np.where(foot, 40.0, np.inf))        # outside the heel the generic hand is "far above"
    return env, foot, zh


def build_generic(hand_length, hand_width, wrist_width, wrist_thickness, curl_diameter, grid=None, o=None):
    o = dict(DEFAULTS, **(o or {}))
    if grid is None:
        grid = Grid((0, -hand_width / 2), (hand_length, hand_width / 2), o['pitch'])
    env, foot, zh = generic_skin(grid, hand_length, hand_width, wrist_width, wrist_thickness)
    floor = -(IFACE['seat_drop'] - IFACE['tray_t'])
    th = np.radians(65.0)
    r = min((curl_diameter - 0.8) / 2, o['bar_max_d'] / 2)
    bar = dict(centre=[0.57 * hand_length, -0.10 * hand_width, zh + curl_diameter / 2], direction=[np.cos(th), -np.sin(th), 0.0], r=r, s0=-0.36 * hand_width, s1=0.36 * hand_width)
    top, outline, _ = pad_top(env, foot, grid, o, floor, bar)
    pad, _ = build_pad(top, outline, grid, floor)
    recipe = dict(heel_lowest_z=round(zh, 2), heel_lowest_x=round(0.24 * hand_length, 1), bowl_x_range=[1.0, round(0.40 * hand_length, 1)],
                  bar_diameter=round(2 * r, 2), bar_centre=[round(v, 2) for v in bar['centre']], bar_angle_deg=65.0)
    return pad, recipe
