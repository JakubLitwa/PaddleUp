"""Signed distance of a closed triangle mesh on a regular grid (negative inside). Used by the fitted grip (grip.py).

Sign: the mesh is cut by the grid's z planes and every cut is filled, so the sign is exact at the nodes.
Size: far from the surface it is the grid's own Euclidean distance transform (scipy.ndimage.distance_transform_edt, to the nearest node of the
other kind, less half a pitch); within `band` mm of the surface it is the exact distance to the triangles round the nearest vertices
(closest point on a triangle: C. Ericson, Real-Time Collision Detection, 2005, section 5.1.5)."""
import numpy as np, shapely
from scipy.spatial import cKDTree
from scipy import ndimage


class Field:
    def __init__(self, lo, pitch, values):
        self.lo, self.h, self.v = np.asarray(lo, float), float(pitch), values

    @property
    def shape(self):
        return self.v.shape

    def axes(self):
        return [self.lo[k] + self.h * np.arange(self.v.shape[k]) for k in range(3)]

    def at(self, P, order=1):
        P = np.atleast_2d(P)
        return ndimage.map_coordinates(self.v, ((P - self.lo) / self.h).T, order=order, mode='nearest')

    def grad(self, P, e=None):
        e = e or self.h
        g = np.zeros((len(P), 3))
        for k in range(3):
            d = np.zeros(3); d[k] = e
            g[:, k] = (self.at(P + d) - self.at(P - d)) / (2 * e)
        return g


def occupancy(mesh, lo, shape, h):
    xs, ys = lo[0] + h * np.arange(shape[0]), lo[1] + h * np.arange(shape[1])
    X, Y = np.meshgrid(xs, ys, indexing='ij')
    occ = np.zeros(shape, bool)
    zs = lo[2] + h * np.arange(shape[2])
    secs = mesh.section_multiplane(plane_origin=[0, 0, 0], plane_normal=[0, 0, 1], heights=zs)
    for k, sec in enumerate(secs):
        if sec is None:
            continue
        T = sec.metadata.get('to_3D', None)
        polys = [p for p in sec.polygons_full if p is not None and p.area > 1e-6]
        if not polys:
            continue
        # section_multiplane returns 2D paths in the plane's own axes; map the grid nodes into them
        Ti = np.linalg.inv(T)
        q = np.c_[X.ravel(), Y.ravel(), np.full(X.size, zs[k]), np.ones(X.size)] @ Ti.T
        inside = np.zeros(X.size, bool)
        for p in polys:
            inside |= shapely.contains_xy(p, q[:, 0], q[:, 1])
        occ[:, :, k] = inside.reshape(X.shape)
    return occ


def _closest_on_tris(P, A, B, C):
    """Distance from points P (n, 3) to triangles (n, k, 3): closest point on a triangle after Ericson 5.1.5, vectorised."""
    P = P[:, None, :]
    ab, ac, ap = B - A, C - A, P - A
    d1, d2 = (ab * ap).sum(-1), (ac * ap).sum(-1)
    bp = P - B; d3, d4 = (ab * bp).sum(-1), (ac * bp).sum(-1)
    cp = P - C; d5, d6 = (ab * cp).sum(-1), (ac * cp).sum(-1)
    va, vb, vc = d3 * d6 - d5 * d4, d5 * d2 - d1 * d6, d1 * d4 - d3 * d2
    den = va + vb + vc
    den = np.where(np.abs(den) < 1e-30, 1e-30, den)
    v, w = vb / den, vc / den
    Q = A + ab * v[..., None] + ac * w[..., None]                       # inside the face
    def put(mask, val):
        np.copyto(Q, val, where=mask[..., None])
    with np.errstate(divide='ignore', invalid='ignore'):
        t_ab = np.clip(d1 / np.where(d1 - d3 == 0, 1, d1 - d3), 0, 1)
        t_ac = np.clip(d2 / np.where(d2 - d6 == 0, 1, d2 - d6), 0, 1)
        t_bc = np.clip((d4 - d3) / np.where((d4 - d3) + (d5 - d6) == 0, 1, (d4 - d3) + (d5 - d6)), 0, 1)
    put((vc <= 0) & (d1 >= 0) & (d3 <= 0), A + ab * t_ab[..., None])
    put((vb <= 0) & (d2 >= 0) & (d6 <= 0), A + ac * t_ac[..., None])
    put((va <= 0) & (d4 - d3 >= 0) & (d5 - d6 >= 0), B + (C - B) * t_bc[..., None])
    put((d1 <= 0) & (d2 <= 0), A)
    put((d3 >= 0) & (d4 <= d3), B)
    put((d6 >= 0) & (d5 <= d6), C)
    return np.linalg.norm(P - Q, axis=-1).min(1)


class Exact:
    """Exact unsigned distance to a mesh for points near it: triangles round the k nearest vertices."""
    def __init__(self, mesh, k=4):
        self.V, self.F = np.asarray(mesh.vertices), np.asarray(mesh.faces)
        self.tree = cKDTree(self.V)
        self.k = k
        vf = mesh.vertex_faces                                            # (n_v, max_valence), padded with -1
        self.vf = vf[:, :16] if vf.shape[1] > 16 else vf

    def dist(self, P, chunk=20000):
        out = np.empty(len(P))
        for s in range(0, len(P), chunk):
            p = P[s:s + chunk]
            _, vi = self.tree.query(p, k=self.k)
            fi = self.vf[vi].reshape(len(p), -1)
            bad = fi < 0
            fi = np.where(bad, fi[:, :1], fi)
            T = self.V[self.F[fi]]
            out[s:s + chunk] = _closest_on_tris(p, T[:, :, 0], T[:, :, 1], T[:, :, 2])
        return out


def build(mesh, pitch=0.5, margin=12.0, band=2.0, lo=None, hi=None, log=None):
    """lo, hi: corners of the grid (lo is the first node); by default the mesh bounds grown by `margin`."""
    import time
    t0 = time.time()
    b = mesh.bounds
    lo = np.floor((b[0] - margin) / pitch) * pitch if lo is None else np.asarray(lo, float)
    hi = b[1] + margin if hi is None else np.asarray(hi, float)
    shape = tuple(int(np.ceil((hi[k] - lo[k]) / pitch)) + 1 for k in range(3))
    occ = occupancy(mesh, lo, shape, pitch)
    if log: log('occupancy %.1f s' % (time.time() - t0))
    d_out = ndimage.distance_transform_edt(~occ) * pitch - 0.5 * pitch          # outside nodes: distance to the solid
    d_in = ndimage.distance_transform_edt(occ) * pitch - 0.5 * pitch            # inside nodes: distance to the outside
    d = np.where(occ, d_in, d_out)
    if log: log('distance transform %.1f s' % (time.time() - t0))
    near = np.argwhere(d < band)
    if len(near):
        G = lo + pitch * near
        d[tuple(near.T)] = Exact(mesh).dist(G)
    if log: log('exact band (%d nodes) %.1f s' % (len(near), time.time() - t0))
    return Field(lo, pitch, np.where(occ, -d, d).astype(np.float32)), occ
