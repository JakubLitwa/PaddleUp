"""Fitted grip (handgen 4.2, `build --grip fitted`): the pad's round bar becomes a bar that the scanned hand has shaped.

A relaxed hand leaves a hollow under its curled fingers, in front of the heel of the palm. The round bar of release 4.1 is the largest
straight cylinder that fits there, made a little smaller; it touches the skin along lines at best. The fitted grip is made in six steps, all
of them from the scan:

 1. Smoothed skin. The hand's signed distance field (sdf.py) is blurred with a Gaussian of `grip_sigma` mm. Creases, skin texture and scan
    noise go; the hand's shape stays. The grip is shaped against this smoothed skin, held `grip_gap` mm off it.
 2. Ball chain. At every millimetre along the curl axis, the largest ball that fits between the smoothed skin and the pad (centre within
    `grip_tube` mm of the axis in plan, skin above it). A station counts while the skin lies within `grip_cover` mm of its ball on both
    sides, the heel behind and the fingers in front, and while its ball stays inside the pad's outline; the grip ends where the fingers end.
 3. Bar. A barrel through those balls: round across the axis at every station, centre line and radius fitted over the stations with a
    parabola, radius `grip_swell` times the radius that fits, a flattened dome at each end. With a swell of 1 the bar only touches the
    hand; above 1 it would press into it, so:
 4. Carved, with room to land. Wherever the smoothed skin (less the gap) is lower than the bar, the bar is cut down to it; those parts
    of the grip are the hand's own shape, the rest stays round. Beside steep skin the grip does not stand as a wall: it keeps
    `grip_slack` mm of room sideways and then falls away at `grip_slope` degrees, the rule the pad of release 4.1 follows everywhere.
 5. Fillet. A ball of radius `grip_fillet` rolled over the top fills the inward corners where the grip meets the pad (a morphological
    closing with a ball), and the result is cut once more by the limits of step 4.
 6. Rolling ball, last. The surface is replaced by the top of all balls of radius `grip_ball` that fit under it (a morphological opening
    with a ball: J. Serra, Image Analysis and Mathematical Morphology, 1982; S. R. Sternberg, Grayscale morphology, CVGIP 35, 1986). No
    outward feature of the grip is then sharper than that radius, and the step never raises the surface, so the limits still hold.

The pad's own last rule (0.2 mm under the lowest skin as scanned over each node) is part of the limit of step 4, and the room to land
is kept from that skin as well as from the smoothed skin. After
step 6 the surface is checked once more against the skin as scanned, in three dimensions, at every node and at seven points of every cell;
where it would come closer than `grip_hard_gap` it gives way in a shallow dimple (keep_clear), not in a pit. `build` then intersects the
finished pad with the scan as solids and, while any volume is left, lowers the surface round it again (give_way).

The pad is never lower than the pad of release 4.1 without its bar, and outside the grip it is that pad, node for node. The grip is part
of the pad: no new part, no new fastener, and the pad still prints flat side down without supports (the grip is a height field: it has
no overhang)."""
import numpy as np
from scipy import ndimage
from . import sdf as SDF

GRIP_DEFAULTS = dict(
    grip_sigma=1.2,       # Gaussian that smooths the skin before the grip is shaped against it, mm
    grip_gap=0.3,         # clearance between the grip and the smoothed skin, mm (the clearance to the skin as scanned is reported)
    grip_swell=1.15,      # bar radius = this times the radius of the largest ball that fits at each station
    grip_ball=6.0,        # rolling ball of step 5, mm: least radius of any outward curve on the grip
    grip_fillet=4.0,      # ball of step 6, mm: radius of the fillet between grip and pad
    grip_tube=10.0,       # ball centres are searched within this distance of the curl axis, in plan, mm
    grip_cover=5.0,       # a station counts while the smoothed skin lies within this distance of its ball on the finger side and on the heel side, mm
    grip_reach=45.0,      # stations are searched this far each side of the curl centre, mm
    grip_min_len=20.0,    # a shorter run of stations is no grip: the pad then keeps its round bar
    grip_blend=4.0,       # the changes of steps 5 and 6 fade out over this distance round the grip, mm
    grip_hard_gap=0.1,    # the grip is nowhere closer than this to the skin as scanned, mm
    grip_inside=0.9,      # a station counts while this share of its ball's plan outline lies inside the pad's outline
    grip_slack=0.75,      # a hand that lands this far off sideways, in any direction, is not touched by the grip, mm (it covers the eight
                          # neighbouring nodes, 0.5 and 0.71 mm away, which is what the pad's own rule does)
    grip_slope=55.0,      # beside steeper skin the grip falls away at this slope, degrees from the horizontal (the pad's own rule, pad_slope_deg)
    grip_end=0.5,         # length of the cap at each end of the bar, as a share of the bar's radius there
    grip_draft=78.0,      # slope of the bar's flank below its widest line, degrees from the horizontal
    grip_dimple=0.02,     # where the skin as scanned comes too near, the grip gives way in a dimple of this curvature, 1/mm (depth = this x radius squared)
)


def ball(radius, pitch):
    """Upper half of a ball as a structuring function on the grid, and its footprint."""
    n = int(np.floor(radius / pitch))
    a = np.arange(-n, n + 1) * pitch
    d2 = a[:, None] ** 2 + a[None, :] ** 2
    fp = d2 <= radius ** 2 + 1e-9
    return np.where(fp, np.sqrt(np.maximum(radius ** 2 - d2, 0.0)), 0.0), fp


def roll_under(f, radius, pitch):
    """Top of all balls of this radius that fit under the surface f (opening). Never above f."""
    s, fp = ball(radius, pitch)
    return np.minimum(ndimage.grey_opening(f, footprint=fp, structure=s, mode='nearest'), f)


def roll_over(f, radius, pitch):
    """Underside of all balls of this radius that fit over the surface f (closing). Never below f."""
    s, fp = ball(radius, pitch)
    return np.maximum(ndimage.grey_closing(f, footprint=fp, structure=s, mode='nearest'), f)


def offset_skin(field, gap):
    """Height of the surface `gap` mm under the smoothed skin over each grid column, seen from below (+inf where no skin lies above)."""
    v, h, z0 = field.v, field.h, field.lo[2]
    hit = v <= gap
    has = hit.any(2)
    k = np.argmax(hit, axis=2)
    k0 = np.clip(k - 1, 0, None)
    ii, jj = np.indices(k.shape)
    f0, f1 = v[ii, jj, k0], v[ii, jj, k]
    t = np.where((k > 0) & (f0 > gap), (f0 - gap) / np.maximum(f0 - f1, 1e-6), 0.0)
    return np.where(has, z0 + h * (k0 + np.clip(t, 0.0, 1.0)), np.inf), has


def _dimple(L, curve, pitch):
    """Every node that must go down by L takes its surroundings with it: L - curve * r^2 at distance r (grey dilation with a paraboloid)."""
    n = int(np.ceil(np.sqrt(L.max() / curve) / pitch))
    a = np.arange(-n, n + 1) * pitch
    return np.clip(ndimage.grey_dilation(L, structure=-curve * (a[:, None] ** 2 + a[None, :] ** 2), mode='constant', cval=0.0), 0.0, None)


# where the top surface of one grid cell is sampled, as weights of its four corner nodes a (i, j), b (i+1, j), c (i+1, j+1), d (i, j+1):
# the two triangles of hfield.prism (a b c and a c d): their centroids, and the midpoints of the four sides and of the diagonal a c
_CELL = np.array([[1, 1, 1, 0], [1, 0, 1, 1], [1, 1, 0, 0], [0, 1, 1, 0], [0, 0, 1, 1], [1, 0, 0, 1], [1, 0, 1, 0]], float)
_CELL /= _CELL.sum(1, keepdims=True)
_OFF = np.array([[0, 0], [1, 0], [1, 1], [0, 1]], float)


def keep_clear(top, field, grid, where, gap, curve, floor_top=None, rounds=60):
    """Lower the surface where it comes closer than `gap` to the skin as scanned. Checked at the nodes and, in every cell, at the centroids
    of its two triangles and the midpoints of their edges. The surface does not give way node by node, which would leave pits: every node
    that must go down takes its surroundings with it in a shallow dimple (_dimple). floor_top: node heights the surface never goes below.
    Returns the surface, the number of nodes that needed lowering and the deepest lowering."""
    top = top.copy()
    start = top.copy()
    need_any = np.zeros(top.shape, bool)
    ii, jj = np.where(where)
    cells = where[:-1, :-1] | where[1:, :-1] | where[:-1, 1:] | where[1:, 1:]
    ci, cj = np.where(cells)
    for _ in range(rounds):
        L = np.zeros(top.shape)
        low = gap - field.at(np.c_[grid.X[ii, jj], grid.Y[ii, jj], top[ii, jj]])
        bad = low > 0
        L[ii[bad], jj[bad]] = low[bad] + 0.02
        z4 = np.stack([top[ci, cj], top[ci + 1, cj], top[ci + 1, cj + 1], top[ci, cj + 1]], 1)
        for wq in _CELL:
            xy = wq @ _OFF
            lowc = gap - field.at(np.c_[grid.X[ci, cj] + xy[0] * grid.p, grid.Y[ci, cj] + xy[1] * grid.p, z4 @ wq])
            badc = lowc > 0
            for (di, dj), wk in zip(((0, 0), (1, 0), (1, 1), (0, 1)), wq):
                if wk > 0:
                    np.maximum.at(L, (ci[badc] + di, cj[badc] + dj), lowc[badc] + 0.02)
        if L.max() <= 0:
            break
        need_any |= L > 0
        top -= _dimple(L, curve, grid.p)
        if floor_top is not None:
            top = np.maximum(top, floor_top)
    return top, int(need_any.sum()), float((start - top).max())


def give_way(top, grid, points, depth, curve, floor_top=None):
    """Lower the surface by `depth` in dimples round the given points (x, y): used when the exact solid of the pad still overlaps the scan."""
    L = np.zeros(top.shape)
    i0, j0 = np.floor((points[:, 0] - grid.x0) / grid.p).astype(int), np.floor((points[:, 1] - grid.y0) / grid.p).astype(int)
    for di in (0, 1):
        for dj in (0, 1):
            L[np.clip(i0 + di, 0, grid.nx - 1), np.clip(j0 + dj, 0, grid.ny - 1)] = depth
    out = top - _dimple(L, curve, grid.p)
    return np.maximum(out, floor_top) if floor_top is not None else out


def fitted_grip(dev, grid, top0, outline, floor, curl, o, env_e=None, pad_gap=0.2, log=None):
    """dev: hand mesh in the device frame. top0: pad top without a bar (node heights). outline: nodes of the pad.
    env_e, pad_gap: lowest skin as scanned over each node (build.lower_envelope) and the gap the pad keeps under it (build.pad_top).
    When given, the grip keeps that gap too, with the same room to land as from the smoothed skin. The pad's rule takes the lowest
    skin of the eight neighbouring nodes as well; here the slack of step 4, which is wider than one node, does that.
    Returns the new node heights and a dictionary for the report, or (None, info) when the hand leaves no hollow long enough for a grip."""
    p = grid.p
    say = log or (lambda s: None)
    zhi = float(dev.bounds[1][2]) + 4.0
    lo = np.array([grid.x0, grid.y0, floor - 2 * p])
    hi = np.array([grid.x0 + p * (grid.nx - 1), grid.y0 + p * (grid.ny - 1), zhi])
    F, _ = SDF.build(dev, pitch=p, lo=lo, hi=hi, band=2.0)
    assert F.v.shape[:2] == (grid.nx, grid.ny), (F.v.shape, grid.nx, grid.ny)
    Fs = SDF.Field(F.lo, F.h, ndimage.gaussian_filter(F.v, o['grip_sigma'] / p, mode='nearest'))
    g = o['grip_gap']
    envs, has = offset_skin(Fs, g)
    zs = F.lo[2] + p * np.arange(F.v.shape[2])
    say('distance field %s' % (F.v.shape,))

    # ---- step 2: ball chain along the curl axis
    c0 = np.array(curl['centre'], float)
    a = np.array(curl['direction'], float)[:2]; a /= np.linalg.norm(a)
    if a[1] < 0:
        a = -a                                            # stations run from the thumb side (negative) to the little-finger side
    e = np.array([a[1], -a[0]])
    if e[0] < 0:
        e = -e                                            # toward the fingertips
    S = (grid.X - c0[0]) * a[0] + (grid.Y - c0[1]) * a[1]
    U = (grid.X - c0[0]) * e[0] + (grid.Y - c0[1]) * e[1]
    D = np.minimum(Fs.v - g, zs[None, None, :] - top0[:, :, None])
    above = np.flip(np.maximum.accumulate(np.flip(Fs.v <= g, 2), 2), 2)          # skin lies above this node
    D = np.where(above, D, -1.0)
    Dcol, kcol = D.max(2), D.argmax(2)
    del D, above
    tube = (np.abs(U) <= o['grip_tube']) & has
    th_f, th_r = np.radians(np.arange(-30.0, 81.0, 5.0)), np.radians(np.arange(100.0, 211.0, 5.0))
    ring = np.radians(np.arange(0.0, 360.0, 10.0))

    def held(x, y, z, r, th):
        """Least distance from the ball's surface to the smoothed skin (less the gap) over an arc of the ball, in the plane across the axis."""
        P = np.c_[x + r * np.cos(th) * e[0], y + r * np.cos(th) * e[1], z + r * np.sin(th)]
        return float((Fs.at(P) - g).min())

    def inside(x, y, r):
        i = np.clip(np.rint((x + r * np.cos(ring) - grid.x0) / p).astype(int), 0, grid.nx - 1)
        j = np.clip(np.rint((y + r * np.sin(ring) - grid.y0) / p).astype(int), 0, grid.ny - 1)
        return float(outline[i, j].mean())
    rows = []
    for s in np.arange(-o['grip_reach'], o['grip_reach'] + 0.01, 1.0):
        m = tube & (np.abs(S - s) <= 0.5)
        if not m.any():
            continue
        d = np.where(m, Dcol, -1.0)
        i, j = np.unravel_index(np.argmax(d), d.shape)
        r = float(d[i, j])
        if r < 2.0:
            continue
        x, y, z = grid.X[i, j], grid.Y[i, j], zs[kcol[i, j]]
        # skin off the finger side and off the heel side of the ball; share of the swollen ball's outline inside the pad
        rows.append((float(s), float(U[i, j]), float(z), r, held(x, y, z, r, th_f), held(x, y, z, r, th_r), inside(x, y, o['grip_swell'] * r)))
    rows = np.array(rows)
    info = dict(options={k: o[k] for k in GRIP_DEFAULTS}, axis=dict(centre=c0.tolist(), along=a.tolist(), toward_fingertips=e.tolist()))
    if len(rows) == 0:
        return None, dict(info, built=False, why='no ball fits under the hand near the curl axis')
    ok = (rows[:, 4] <= o['grip_cover']) & (rows[:, 5] <= o['grip_cover']) & (rows[:, 6] >= o['grip_inside'])
    lab, n = ndimage.label(ok)
    best = None
    for q in range(1, n + 1):                             # longest run of stations that count; of equal runs, the one nearest the curl centre
        idx = np.where(lab == q)[0]
        key = (len(idx), -abs(rows[idx, 0]).min())
        if best is None or key > best[0]:
            best = (key, idx)
    info['stations'] = [dict(s=r[0], u=round(r[1], 2), z=round(r[2], 2), ball_radius=round(r[3], 2), skin_off_front=round(r[4], 2), skin_off_rear=round(r[5], 2),
                             inside_outline=round(r[6], 2), counts=bool(k)) for r, k in zip(rows.tolist(), ok.tolist())]
    if best is None or np.ptp(rows[best[1], 0]) + 1.0 < o['grip_min_len']:
        return None, dict(info, built=False, why='the hollow under the fingers is shorter than grip_min_len')
    idx = best[1]
    s_k, u_k, z_k, r_k = rows[idx, 0], rows[idx, 1], rows[idx, 2], rows[idx, 3]
    # ---- step 3: the bar. Centre line and radius are low-order fits over the stations, so the bar is a plain barrel: a round section
    # across the axis at every station, and at each end a cap `grip_end` times its radius long (a flattened dome). Below its widest line the
    # bar does not drop straight down: it widens at `grip_draft` degrees from the horizontal, so its flank is a steep smooth slope.
    deg = 2 if len(idx) >= 9 else 1
    pu, pz, pr = np.polyfit(s_k, u_k, deg), np.polyfit(s_k, z_k, deg), np.polyfit(s_k, r_k, deg)
    sc = np.clip(S, s_k[0], s_k[-1])
    R0 = o['grip_swell'] * np.polyval(pr, sc)
    Le = o['grip_end'] * R0
    qa, qb = (U - np.polyval(pu, sc)) / R0, np.abs(S - sc) / Le
    q = np.hypot(qa, qb)                                   # 1 on the bar's widest line, seen in plan
    m = (R0 * qa * qa + Le * qb * qb) / np.maximum(q * q, 1e-9)
    zc = np.polyval(pz, sc)
    cap = zc + np.where(q < 1.0, R0 * np.sqrt(np.clip(1.0 - q * q, 0.0, None)), -(q - 1.0) * m * np.tan(np.radians(o['grip_draft'])))
    R_f = o['grip_swell'] * np.polyval(pr, s_k)
    foot = q < 1.0
    # ---- step 4: carved by the offset skin, with room to land. The limit over a plan point is not the offset skin straight above it but
    # the lowest of the offset skin all round, each raised by tan(grip_slope) for every millimetre beyond `grip_slack`:
    #     limit(p) = min over q of [ skin(q) + tan(grip_slope) * max(|p - q| - grip_slack, 0) ]
    # (a grey erosion with a flat-topped cone; the pad of release 4.1 uses the same rule without the flat top, build.slope_limited).
    # So the grip lies close under skin that is nearly level, and beside steep skin it falls away at grip_slope instead of standing as
    # a wall: a hand that lands up to grip_slack off sideways is not touched, and beyond that it is raised by tan(grip_slope) per mm at most.
    envs_as_scanned = envs
    if env_e is not None:                                  # the pad's own last rule joins the limit before the cone is applied, so the room to
        envs = np.minimum(envs, np.where(np.isfinite(env_e), env_e - pad_gap, np.inf))     # land is kept from the skin as scanned as well
    box = np.where(cap > floor)
    rad = min(30.0, (float(cap[box].max()) - floor) / np.tan(np.radians(o['grip_slope'])) + o['grip_slack'] + 2 * p)
    n = int(np.ceil(rad / p))
    m = grid.it(8.0)                                       # the limit is also wanted round the bar, where its fillet goes
    i0, i1 = max(0, box[0].min() - m), min(grid.nx, box[0].max() + m + 1)
    j0, j1 = max(0, box[1].min() - m), min(grid.ny, box[1].max() + m + 1)
    aa = np.arange(-n, n + 1) * p
    dd = np.hypot(aa[:, None], aa[None, :])
    cone = -np.tan(np.radians(o['grip_slope'])) * np.maximum(dd - o['grip_slack'], 0.0)
    big = np.pad(np.where(np.isfinite(envs), envs, 1e3), n, mode='constant', constant_values=1e3)      # no skin beyond the grid
    lim = ndimage.grey_erosion(big[i0:i1 + 2 * n, j0:j1 + 2 * n], footprint=dd <= rad + 1e-9, structure=cone, mode='constant', cval=1e3)[n:-n, n:-n]
    plain = envs
    envs = plain.copy()
    envs[i0:i1, j0:j1] = np.where(lim > 500, np.inf, lim)
    T1 = np.maximum(top0, np.minimum(cap, envs))
    # ---- step 5 (fillet) and step 6 (rolling ball, last), both faded out round the grip
    near = ndimage.distance_transform_edt(~foot) * p
    w = np.clip(1.0 - (near - o['grip_fillet']) / o['grip_blend'], 0.0, 1.0)
    w = w * w * (3 - 2 * w)
    T2 = np.minimum(roll_over(T1, o['grip_fillet'], p), np.maximum(envs, top0))     # fillet, held under the limit
    T2 = w * T2 + (1 - w) * T1
    T3 = w * roll_under(T2, o['grip_ball'], p) + (1 - w) * T2                         # nothing after this step raises the surface
    T3 = np.maximum(T3, top0)                              # never below the pad of release 4.1 without its bar
    # ---- the skin as scanned, in three dimensions
    top, n_cut, deepest = keep_clear(T3, F, grid, (T3 > top0 + 1e-6), o['grip_hard_gap'], o['grip_dimple'], floor_top=top0)
    changed = np.abs(top - top0) > 1e-6
    clear = F.at(np.c_[grid.X[changed], grid.Y[changed], top[changed]])
    info.update(built=True, length_mm=float(s_k[-1] - s_k[0]), station_range=[float(s_k[0]), float(s_k[-1])],
                ball_diameter_mm=dict(min=round(float(2 * r_k.min()), 2), max=round(float(2 * r_k.max()), 2), mean=round(float(2 * r_k.mean()), 2)),
                bar_diameter_mm=dict(min=round(float(2 * R_f.min()), 2), max=round(float(2 * R_f.max()), 2), mean=round(float(2 * R_f.mean()), 2)),
                centre_line=dict(u_poly=pu.tolist(), z_poly=pz.tolist(), ball_radius_poly=pr.tolist(), note='u (toward the fingertips), z and the ball radius over the station s, highest power first'),
                top_z=dict(max=round(float(top[foot].max()), 2), mean=round(float(top[foot].mean()), 2)),
                height_over_pad_floor_mm=round(float(top[foot].max() - floor), 2),
                footprint_mm2=round(float(foot.sum() * p * p), 1), nodes_changed=int(changed.sum()),
                carved_share_of_footprint=round(float((envs[foot] < cap[foot]).mean()), 4), carved_share_without_slack=round(float((envs_as_scanned[foot] < cap[foot]).mean()), 4),
                nodes_that_needed_lowering_for_the_skin_as_scanned=n_cut, deepest_lowering_mm=round(deepest, 3),
                clearance_to_skin_as_scanned_mm=dict(min=round(float(clear.min()), 3), p05=round(float(np.quantile(clear, 0.05)), 3), median=round(float(np.median(clear)), 3)),
                volume_added_cm3=round(float((top - top0)[changed].sum() * p * p / 1000), 2))
    aux = dict(field=F, smooth=Fs, envs=envs, cap=cap, foot=foot, w=w, T1=T1, T2=T2, T3=T3, S=S, U=U, rows=rows, idx=idx, top0=top0)
    return top, dict(info, _aux=aux)


def skin_contact(pad_tm, dev, grid, outline, zone=None, limits=(0.5, 1.0, 2.0)):
    """Area of scanned skin that faces the pad and lies within the given distances of the pad's surface, mm2.
    Skin that faces the pad: scan triangles inside the pad's outline whose normal points down (n_z < -0.2) and that are the lowest skin in
    their grid column (within 0.5 mm), so skin hidden behind other skin does not count. Distance: from the triangle's centre to the nearest
    of the pad's surface points (its vertices and triangle centres after one subdivision, at most about 0.18 mm apart).
    zone: optional node mask; then only triangles over it are counted."""
    from scipy.spatial import cKDTree
    C, A, N = dev.triangles_center, dev.area_faces, dev.face_normals
    i, j = grid.index(C)
    low = np.full((grid.nx, grid.ny), np.inf)
    np.minimum.at(low, (i, j), C[:, 2])
    m = outline[i, j] & (N[:, 2] < -0.2) & (C[:, 2] <= low[i, j] + 0.5)
    if zone is not None:
        m &= zone[i, j]
    dense = pad_tm.subdivide()
    d = cKDTree(np.concatenate([dense.vertices, dense.triangles_center])).query(C[m], workers=-1)[0]
    a = A[m]
    out = dict(skin_facing_the_pad_mm2=round(float(a.sum()), 1))
    for lim in limits:
        out['within_%s_mm_mm2' % str(lim).replace('.', 'p')] = round(float(a[d <= lim].sum()), 1)
    out['median_distance_mm'] = round(float(np.median(d)), 3) if len(d) else None
    return out
